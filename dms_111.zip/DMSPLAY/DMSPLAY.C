// program:     DMS Player
// mainfile:    dmsplay.c
//
// file:        dmsplay.c
// created:     7 Apr 1998
// author:	Elliott Lee
// company:	Protocol Software
// e-mail:	tenchi@shell.jps.net
// url:		http://www.jps.net/tenchi/
//
// copyright:   (C) 1998 Elliott Lee
// copyright:   Portions (C) 1998 Sony Computer Entertainment Inc.
//
// description: Loads a DMS file and lets you play it back!

// ......................................................................
// GENERAL INCLUDES
// ......................................................................
#include <libps.h>
#include "../library/padstuff.c"
#include "../library/prnstuff.c"
#include "../library/dms.c"

// ......................................................................
// CONSTANTS
// ......................................................................

#define OT_LENGTH		(2)	  
		// size of ordering table: 2 << OT_LENGTH
		// i.e.	16384 levels of z resolution
#define PACKETMAX		(1000)
#define PACKETMAX2              (PACKETMAX*24)
		// GPU packet space
#define		DMSADDR		0x801c0000
#define         VBADDR          0x80140000
#define         VHADDR          0x80120000
                // VAB stuff

// ......................................................................
// GLOBALS
// ......................................................................
GsOT		WorldOrderingTable[2];
		// Ordering Table handlers
GsOT_TAG        zSortTable[2][1<<OT_LENGTH];   
		// actual Ordering Tables themselves							
PACKET		GpuOutputPacket[2][PACKETMAX2];
		// GPU packet work area
int		Page=0;
		// Current display page
char            *ProgName="DMS Player",
                *ProgVer="1.1.0";
int		VabID;
u_long		PadStatus;

char		buf[1024];

int		scroller=0;
char		scrollertext[1024];

// ......................................................................
// FUNCTION PROTOTYPES
// ......................................................................

// ......................................................................
// in:          -
// out:         -
// desc:	bye bye
// note:	-
// ......................................................................
void CleanUp( void )
{
// clean up
ResetGraph(3);
}

// ......................................................................
// in:          -
// out:         -
// desc:        wait and flip video pages
// note:	-
// ......................................................................
void FlipPage( void )
{
  // find which buffer is active
  // set address for GPU scratchpad area
  // clear the ordering table
  Page = GsGetActiveBuff();
  GsSetWorkBase( (PACKET*)GpuOutputPacket[Page]);
  GsClearOt(0, 0, &WorldOrderingTable[Page]);

  // wait for end of drawing
  // wait for V_BLANK interrupt
  DrawSync(0);
  VSync(0);

  // swap double buffers
  GsSwapDispBuff();

  // register clear-command: clear to black
  // register request to draw ordering table
  GsSortClear(0x0, 0x0, 0x60,&WorldOrderingTable[Page]);
  GsDrawOt(&WorldOrderingTable[Page]);

  // Clear our work area.
  PrintClear(0);
}

// ......................................................................
// in:          -
// out:         -
// desc:	init routines
// note:	-
// ......................................................................
void Init( void )
{
printf( "\n%s v%s\n(c) 1998 Elliott Lee, tenchi@jps.net\n",
        ProgName,ProgVer );
printf( "Portions (c) 1998 Sony Computer Entertainment, Ltd.\n\n" );

printf( "Init()..." );

// NTSC mode
SetVideoMode( MODE_NTSC );      

// non-interlace, use GsGPU offset
ResetGraph(0);
GsInitGraph(320 ,240, GsOFSGPU|GsNONINTER, 1, 0);                
GsDefDispBuff(0, 0, 0, 256);

// set up the ordering table handlers
WorldOrderingTable[0].length = OT_LENGTH;
WorldOrderingTable[1].length = OT_LENGTH;
WorldOrderingTable[0].org = zSortTable[0];
WorldOrderingTable[1].org = zSortTable[1];

// set up the controller pad
PadInit();

// set up print stuff
PrintInit(960,256,0,34,26,8,16);

printf( "Done!\n" );
}

// ......................................................................
// in:          -
// out:         -
// desc:	main
// note:	-
// ......................................................................
int main (void)
{
int	buttondown=0;
int	Program=0;
int	Tone=0;
int	Note=48;
int	Volume=127;
int	Repeatclock=0;
int	Row=0;
int	CurType=0;
int	Clock=0;
int	MsgClock=0;
char	Msg[80];
int	inc;
int	lastvoice;
int	revdepth=32;

char	input;
int	c;
DMS	d;
int	i;
int	stat;
int	row,maxrow;
DMS_EVENT     e;
int	r;
int	t;
int	rowleft=0;
long	clk=0;
int	vol=256;

sprintf( scrollertext,
	"%s v%s        "
	"(c) 1998 Elliott Lee        "
	"tenchi@jps.net        "
	"See dmsplay.txt for instructions.        ",
	ProgName,ProgVer );

SsSetMVol(120,120);
SsUtSetReverbType( SS_REV_TYPE_HALL );
SsUtReverbOn();
SsUtSetReverbDepth(revdepth,revdepth);

// Initialize
Init();
printf( "DMSInit()..." );
stat=DMSInit(&d,0,DMS_NTSC,(char *)VHADDR,(char *)VBADDR,(char *)DMSADDR);
printf( "Done!\n" );
printf( "DMS Status: %d\n",stat	);
printf( "Events:     %d\n",d.Events );
printf( "VAB:        %d\n",d.VabID );

printf( "DEBUG: number of orders: %d\n",d.Orders );

if( stat!=DMS_OK )
  return;

printf( "\n\n"
	"HOW TO USE THIS CRAPPY PLAYER:\n"
	"  Left, Right    Change tempo\n"
	"  Up, Down       Change master volume\n"
	"  [], /\\         Semitone tune*\n"     
	"  X, ()          Previous/next order\n"     
	"  L2, R2         Change reverb depth\n"
	"  L1, R1         Pause song\n"
	"  Start          Reset the song\n"
	"  Select         Quit\n"
	"\n"
	"  *Use this to find the correct pitch of a resampled S3M!  Use\n"
	"  this as the value to the \"-n\" parameter.\n"
	"\n"
	);

PadStatus = PadGet();
while( !(PadStatus & PAD1SELECT) )
  {
  FlipPage();
  PadStatus = PadGet();

  if( !(PadStatus&PAD1L1 || PadStatus&PAD1R1) )
    DMSPoll(&d);

  PrintClear(0);

  // print some stuff about our song!
  sprintf( buf,"[ %s ]",d.SongName );
  PrintXY(17-(strlen(buf)/2),0,buf);

  sprintf( buf,
	"VOL %d\n"
	"RVB %d\n"
	"TMP %d\n"
	"SPD %d\n"
	"\n"
	"ORD %d\n"
	"PAT %d\n"
	"ROW %d\n"
	"TIM %d\n"
	"\n"
	"TUN %d\n",
	d.MasterVol,
	revdepth,
	d.CurTempo,
	d.CurSpeed,
	d.CurOrder,
	d.AddrDMSOrder[d.CurOrder],
	d.CurRow,
	d.EventTime,
	d.NoteCor
	);
  PrintXY( 27,5,buf );

  // Real-time clock!
  sprintf( buf,"TIME %0.2d:%0.2d.%0.2d",
    clk/(d.VideoRefresh*60),(clk/d.VideoRefresh)%60,
    (clk*100/d.VideoRefresh)%100 );
  PrintXY( 1,3,buf );
  clk++;

  PrintXY(1,5,
	"Evnt Time Ch NotIn Vo Cmd\n"
	"==== ==== == ===== == ==="
	);

  row = d.EventPtr;
  for( r=0; r<9; r++ )
    {
    if( DMSGetEvent(&d,row+r,&e)==DMS_OK )
      {
      sprintf( buf,"%4d %4d %2d %3d%2x %2x %c%0.2x",
	row+r,
	e.Time,
        e.Channel,
	e.Note,
	e.Instrument,
        e.Volume,
	e.Command+'A'-1,
	e.Info
	);
      }  // if( DMSGetEvent(d.AddrDMSSeq,row+r,&e)==DMS_OK )
    else
      sprintf( buf,"Out of range" );
    PrintXY( 1,r+7,buf );
    }  // for( r=0; r<9; r++ )

  // show the channel stats
  for( c=0; c<DMS_MAX_CHANNELS; c++ )
    {
    sprintf( buf,"%x",c );
    PrintXY( (c*2)+2,17,buf );
    PrintXY( (c*2)+2,18,"==" );
    }
  PrintXY( 0,19,"N" );
  for( c=0; c<DMS_MAX_CHANNELS; c++ )
    {
    if( (unsigned int)d.Chan2Voice[c]>254 )
      sprintf( buf,".." );
    else
      sprintf( buf,"%x",(unsigned int)d.ChanNote[c] );
    PrintXY( (c*2)+2,19,buf );
    }
  PrintXY( 0,20,"I" );
  for( c=0; c<DMS_MAX_CHANNELS; c++ )
    {
    if( (unsigned int)d.Chan2Voice[c]>254 )
      sprintf( buf,".." );
    else
      sprintf( buf,"%x",(unsigned int)d.ChanInstr[c] );
    PrintXY( (c*2)+2,20,buf );
    }
  PrintXY( 0,21,"V" );
  for( c=0; c<DMS_MAX_CHANNELS; c++ )
    {
    if( (unsigned int)d.Chan2Voice[c]>254 )
      sprintf( buf,".." );
    else
      sprintf( buf,"%x",(unsigned int)d.ChanVol[c]>>8 );
    PrintXY( (c*2)+2,21,buf );
    }
  PrintXY( 0,22,"P" );
  for( c=0; c<DMS_MAX_CHANNELS; c++ )
    {
    if( (unsigned int)d.Chan2Voice[c]>254 )
      sprintf( buf,".." );
    else
      sprintf( buf,"%x",(unsigned int)d.ChanPan[c] );
    PrintXY( (c*2)+2,22,buf );
    }
  PrintXY( 0,23,"C" );
  for( c=0; c<DMS_MAX_CHANNELS; c++ )
    {
    if( (unsigned int)d.Chan2Voice[c]>254 )
      sprintf( buf,".." );
    else
      sprintf( buf,"%x",(unsigned int)d.Chan2Voice[c] );
    PrintXY( (c*2)+2,23,buf );
    }

  // put a scroller on the bottom just for the hell of it...
  scroller = (clk/15)%strlen(scrollertext);
  PrintXY( 0,25,&scrollertext[scroller] );
  PrintXY( strlen(scrollertext)-scroller,25,scrollertext );

  GsDrawOt(&WorldOrderingTable[Page]);
  PrintFlush();

  if( PadStatus&PAD1START )
    DMSSongReset(&d);
  if( PadStatus&PAD1LEFT )
    d.CurTempo--;
  if( PadStatus&PAD1RIGHT )
    d.CurTempo++;
  if( PadStatus&PAD1UP && d.MasterVol<255)
    d.MasterVol++;
  if( PadStatus&PAD1DOWN && d.MasterVol>0)
    d.MasterVol--;
  if( PadStatus&PAD1SQUARE && clk%10==0 )
    d.NoteCor--;
  if( PadStatus&PAD1TRI && clk%10==0 )
    d.NoteCor++;
  if( PadStatus&PAD1CROSS && clk%10==0 )
    DMSOrderJump(&d,d.CurOrder-1);
  if( PadStatus&PAD1CIRCLE && clk%10==0 )
    DMSOrderJump(&d,d.CurOrder+1);
  if( PadStatus&PAD1L2 && revdepth>0 )
    { revdepth--; SsUtSetReverbDepth(revdepth,revdepth); }
  if( PadStatus&PAD1R2 && revdepth<127 )
    { revdepth++; SsUtSetReverbDepth(revdepth,revdepth); }
  }  // while( !(PadStatus & PAD1SELECT) )

DMSDeInit(&d);

CleanUp();
return(0);
}

// [end]
