// program:	S3M to SEQ Converter
// mainfile:	s2s.c
//
// file:	s2s.c
// created:	16 March 1998
// author:	Elliott Lee
// company:	Protocol Software
// e-mail:      tenchi@shell.jps.net
// url:         http://www.jps.net/tenchi
//
// copyright:	(C) 1998 Elliott Lee
// copyright:	Scream Tracker (C) 1994 Future Crew
//
// description: Converts S3M-type MODule files to SEQ format.
//
// compiler:	Borland Turbo C++ 3.0
//
// references:	Scream Tracker 3.21 by Future Crew: TECH.DOC.
//
// notes:	This is a quick-n-dirty script.  Not much documentation
//		is available.
//
//		In general, it processes an S3M file and creates the
//		batch file you need to turn it into a VAB followed
//		by a DMS (Digital Music Sequence) file which can be
//		played back with my Yaroze DMS library.
//
//		See the README.TXT for the most current documentation.
//
// notes:	TIPS ON MAKING COMPATIBLE S3M MUSIC:
//		  -  Use Scream Tracker v3.21 (final release) or Impulse
//		     Tracker (Sample mode, not Instrument mode).
//		  -  At the start of every pattern, be sure to set the
//		     panning positions and speed.  I don't save the
//		     defaults!
//		  -  Make sure all instruments have the same speed
//		     C4 frequency) because AIFF2VAG seems to COMPLETELY
//		     ignored this!  :(  Your instruments will all be
//		     out of tune otherwise.
//		  -  All samples will NOT be affected by the SPU reverb,
//		     unless you tell S2S to.  Put the string "[r]" in the
//		     sample name to enable reverbing.
//		  -  To save memory, cut out the reverb in the samples
//		     and let the PSX hardware do it for you!
//		  -  Only use the effects described below.  All other
//		     ones will just be ignored for now.
//		  -  Keep your sample sizes SMALL!
//		  -  8-bit is converted to 16-bit.  So, use 16-bits when
//		     possible for better quality.
//		  -  Looping samples is done over the ENTIRE wave.  The
//		     Yaroze AIFF2VAG won't let me specify loop points.
//		  -  Looping samples is forward only.
//		  -  Looped samples should have a number of samplings
//		     evenly divisible by 28.  (Not the size of the
//		     sample, but the number of 8-bit or 16-bit samplings!)
//		     You may experience clicking otherwise.
//		  -  Resampling your instruments may make looped instruments
//		     not evenly divisible by 28.
//
// notes:       SEQUENCE FILE STRUCTURE:
//		The sequence file generated is cross between MIDI and MOD
//		data where every non-blank entry in a pattern is recorded
//		as an event to be played back in sequential order.  It is
//		a binary file format containing a header and a data body.
//		(There are 2 chunks for the header and 1 chunk for the
//		pattern data.)  This should allow for expansion
//
//		The Header:
//		===========
//		  Each cell is a byte, numbers are in hex, "\0" is the
//		  NULL character, "x" is just padding (any char), and
//		  descriptions follow.  Remember that for IFF chunk
//		  format, each chunk has a 4-character identifier type,
//		  and a 32-bit chunk length parameter which includes
//		  the 8 bytes for the identified and chunk length.
//
//                     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  00 |   "DMSH"  | DMS Len   |VH|VL|Flags|Chans|Rows |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  10 |Or|Pt|In|Sp|Tm| ...Reserved...                 |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  20 | Song title (31 chars max)                     |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  30 | Song title, cont'd                         |\0|
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  40 |  "DMSO"   | Order Len | Order list.           |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		          :                                      :
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  ?? |  "DMSP"   | Pat Len   | Pattern data.         |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		          :                                      :
//
//		  Descriptions:
//		    "DMSH"	File type keyword.
//		    DMS Len	Length of the Header file chunk only.
//		    VH, VL	Version High and Low (respectively)
//				of this file.  8-bit integers /
//				unsigned chars.
//		    Flags	(Reserved for expansion.)
//		    Chans	Number of channels per pattern.  Should
//				be 16 for a standard S3M.
//		    Rows	Number of rows per pattern.  Should be
//				64 for a standard S3M.
//		    Or   	Number of entries in the order table.
//		    Pt		Number of patterns in this DMS.
//		    In		Number of instruments in VAB.
//		    Sp		Default speed (number of sound frames
//				per row).
//		    Tm		Default tempo (number of beats per minute).
//		    Reserved	You get a prize for decoding this.
//		    Song Title	A string which INCLUDES a NULL byte at
//				the end.  Max is 31 chars, plus the NULL.
//		    "DMSO"	Order section keyword.
//		    Order Len	Length of the Order List data chunk only.
//				Should be 8+Or ("8" for the header, "Or"
//				from the number of orders).  Each entry is
//				an 8-bit value.
//		    "DMSP"	Pattern sequence data keyword.
//		    Pat Len	Length of the pattern data chunk only.  This
//				length is one you'll just have to calculate.
//				See below for the details.
//
//		Order Data
//		==========
//		Any order data that is a valid order is kept (numbers 0
//		to 99, or so).  Any references to blank patterns (e.g.
//		"---" or "+++" tracker entries) are thrown out.  They
//		don't mean anything to DMS.
//
//		Pattern Data
//		============
//		  This is a chunk with inidividual events which should
//		  be in ascending order.  Each event looks like:
//
//                     0  1  2  3  4  5  6  7
//		     +--+--+--+--+--+--+--+--+
//		  00 |Time |Ch|Nt|In|Vl|Cm|If|
//		     +--+--+--+--+--+--+--+--+
//
//		  Description:
//		    Time	An unsigned 16-bit number which is the
//				logical row from the beginning of the file.
//				For 64-row patterns using 0-based numbers:
//
//					pat 0  row 0  => time 0
//					pat 0  row 1  => time 1
//					pat 1  row 0  => time 64
//					pat 14 row 53 => time 949
//
//				There are very likely to be more than 1
//				event per time, so just parse the events
//				that have the same times.  To calculate the
//				location of the event in the pattern data
//				chunk given an order number, you'll have
//				to first calculate the time as:
//
//					time = order * no_rows_per_pat
//
//				Then, do a binary search to isolate the
//				data structure.  To speed things up, you
//				might want to make an index somewhere.
//		    Ch		Channel number.  0..15, or up to the max
//				specified in the DMS header.
//		    Nt		Note to be played 1..253.  254/255 are note
//				key-off commands, 0 is blank.
//		    In		Instrument number, 255 is blank.
//		    Vl		Volume (0..63), 255 is blank.
//		    Cm		Command (0..254), 255 is blank.  Only a
//				handful of commands are supported right
//				now.  See the DMS documentation on which
//				ones work.
//		    If		Command info (0..255).
//
// notes	SPEED/TEMPO:
//		Since the music is sequenced to the vsyncs, we use the
//		following formula to calculate the number of video
//		refreshes per S3M row:
//
//			V = (A*R*5) / (T*2)
//
//		Where:
//			V = approx. number of vsync periods per row
//			A = speed (i.e. from the Axx command)
//			R = number of vsyncs per minute (e.g. NTSC=60, PAL=50)
//			T = tempo (e.g. 120 bpm)
//
//		This is a very BAD implementation as we should be using
//		a high-res timer capable of at least 1/1000 sec.!  Reducing
//		the number of vsyncs per minute (e.g. 25) makes for very
//		bad interger round-off.

// ......................................................................
// GENERAL INCLUDES
// ......................................................................
#include <conio.h>
#include <dos.h>
#include <fcntl.h>
#include <io.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

// ......................................................................
// GLOBAL VARS / DEFINES
// ......................................................................
#define		DMS_SIGNATURE	"Tenchi's Digital Music File"
#define		FLAG_BITSIZE	(0x4)
#define		FLAG_LOOP	(0x1)
#define		MAX_CHANNELS	16
#define		MAX_INST	100
#define		MAX_ORDERS	128
#define		MAX_PATS	128
#define		OCTNORM_LOW	16384l
#define		OCTNORM_HI	32678l
#define		OFS_SAMP	(0x50)
#define		OFS_ORDERS	(0x60)
#define		PREFIX_MAX	256
#define		PROG_NAME	"S3M-to-SEQ"
#define		PROG_VER	"1.1.3"
#define		ROWS_PER_PAT	64
#define		RESAMP_LOW	2048l
#define		SEQVER_HI	1
#define		SEQVER_LO	0
#define		SIZE_WORKBUF	8192
#define		SPEED_THRESHOLD	22050
#define		USAGE		"Usage: s2s [options] <input file>\n"
#define		VSILENT         0
#define		VNORMAL		1
#define		VHEAVY		2

typedef		struct {
		unsigned int	time;
		char		chan;
		char		note;
		char		instr;
		char		vol;
		char		cmd;
		char		cmdinfo;
		} PAT_ENT;

typedef		struct {
		// 0x00..0x1f
		char 		SongName[28];
		char 		Eof;
		char 		Type;
		char 		Pad1[2];

		// 0x20..0x2f
		unsigned int	NumOrders;
		unsigned int	NumInstruments;
		unsigned int	NumPatterns;
		unsigned int	Flags;
		unsigned int	TrackerInfo;
		unsigned int	FileFormat;
		char 		MagicWord[4];

		// 0x30..0x3f
		unsigned char	GlobalVol;
		unsigned char	InitSpeed;
		unsigned char	InitTempo;
		unsigned char	MasterVol;
		unsigned char	UltraClick;
		unsigned char	DefaultPan;
		char 		Pad2[8];
		unsigned int 	Special;

		// 0x40..0x5f
		unsigned char	Panning[32];
		} S3MHEADER;

typedef		struct {
		// 0x00..0x0f
		unsigned char	Type;
		char		Filename[12];
		unsigned char	MemSeg[3];

		// 0x10..0x1f
		unsigned long	Length;
		unsigned long	LoopBegin;
		unsigned long   LoopEnd;
		unsigned char	Volume;
		char		Pad1;
		unsigned char	Packing;
		unsigned char	Flags;

		// 0x20..0x2f
		unsigned long	C2Spd;
		char		Pad2[4];
		unsigned int	Gravis;
		unsigned int	SBLoopExpand;
		unsigned long	SBLastPos;

		// 0x30..0x4f
		char		SampleName[28];
		char		MagicWord[4];
		} S3IHEADER;

typedef		struct {
		unsigned char	note,instr,vol,cmd,cmdinfo;
		} S3MPAT;

unsigned long	C2Spd[MAX_INST];
int		DefaultPan=0;
int		DefaultVol[MAX_INST];
unsigned long	FileLen;
S3MHEADER	Hdr;
char		*Infile=NULL;
int		Instruments=0;
int		InstrumentMap[MAX_INST];
char		LoopChar[MAX_INST];
char		*NoReverb="[r]";
int		NormalizeInst=0;
int		NoteAdjust=0;
char		*NoteVal[12]={
		  "C","C#","D","D#",
		  "E","F","F#","G",
		  "G#","A","A#","B"
		};
int		OctaveAdjust[MAX_INST];
unsigned char	Orders[MAX_ORDERS];
unsigned int	ParaInstruments[MAX_INST];
unsigned int	ParaPats[MAX_PATS];
S3MPAT		Pat[MAX_CHANNELS][ROWS_PER_PAT];
int		Resample=0;
long		ResampleRate=22050;
int		Reverb[MAX_INST];
int		Stereo,MasterVol;
char		Prefix[PREFIX_MAX+1];
char		Title[28+1];
int		Tracker;
char		*TrackerName[5]={
		"ST 3.00","ST 3.01",
		"ST 3.03","ST 3.20",
		"Unknown"
		};
int		ValidOrders=0;
int		Verbosity=VNORMAL;
int		VolumeCorrect=0;
char		*YesNo[2]={"No","Yes"};

// ......................................................................
// PROTOTYPES
// ......................................................................
void		Diagnostic( void );
void 		ExitError( char *msg );
int 		FileExists( char *f );
void 		Init( int argc, char *argv[] );
void		MakeBatch( void );
void		ParseArgs( int argc, char *argv[] );
void 		ParseHeader( int hand );
void 		ProcessFiles( void );
void 		ProcessInst( int hand );
void 		ShowHelp( void );
void 		WarningText( char *msg );

// ......................................................................
// in	  .
// out    .
// desc   Show diagnostic info
// notes  Displays different levels of messages depending on verbosity
// ......................................................................
void Diagnostic( void )
{
int	i,j;

if( Verbosity<VNORMAL )
  return;

printf( "Input file:     %s (%ld bytes, 0x%lx)\n"
	"Output prefix:  %s\n"
	"Song Title:     \"%s\"\n\n",
	Infile,
	FileLen,
	FileLen,
	Prefix,
	Title );

if( Verbosity<VHEAVY )
  return;

printf(	"Tracker: %7s  Master Vol: %-2d Global Vol: %-3d Speed/Tempo: %d/%d\n\r"
	"Stereo:  %-3s      Patterns:   %-2u Orders:     %-3u Instruments: %u\n\r"
	"\n\r",

	TrackerName[Tracker],
	MasterVol,
	Hdr.GlobalVol,
	Hdr.InitSpeed,
	Hdr.InitTempo,
	YesNo[Stereo],
	Hdr.NumPatterns,
	Hdr.NumOrders,
	Hdr.NumInstruments
	);

printf(	"Panning Defaults:\n\r" );
for( j=0; j<32; j+=16 )
  {
  // column headers
  printf( "  " );
  for( i=0; i<16; i++ )
    printf( "c%-0.2d ",i+j+1 );
  printf( "\n" );

  // values
  printf( "  " );
  for( i=0; i<16; i++ )
    {
    if( Hdr.Panning[i+j]==255 )
      printf( "--- " );
    else
      {
      if( Hdr.Panning[i+j]&(0x80) )
	printf( "off " );
      else
	printf( "%-3d ",Hdr.Panning[i+j] );
      }  // else if( Hdr.Panning[i+j]==255 )
    }  // for( i=0; i<16; i++ )
  printf( "\n\n" );
  }  // for( j=0; j<32; j+=16 )

printf( "Order list: (Order no.:Pattern)\n\r" );
for( i=0; i<Hdr.NumOrders; i++ )
  {
  switch(Orders[i])
    {
    case 255:
      printf( "%2d:---  ",i+1,Orders[i] );
      break;
    case 254:
      printf( "%2d:+++  ",i+1,Orders[i] );
      break;
    default:
      printf( "%2d:%-3d  ",i+1,Orders[i] );
      break;
    }  // switch(Orders[i])
  }  // for( i=0; i<Hdr.NumOrders; i++ )
printf( "\n\r\n\r" );

printf( "Instrument pointer list: (Inst no.:Para Offset)\n\r" );
for( i=0; i<Hdr.NumInstruments; i++ )
  {
  printf( "%2d:%0.4x ",i+1,ParaInstruments[i] );
  }  // for( i=0; i<Hdr.NumInstruments; i++ )
printf( "\n\r\n\r" );
}

// ......................................................................
// in	  error message
// out    .
// desc   prints error message and usage and then quits
// notes  .
// ......................................................................
void ExitError( char *msg )
{
printf( "\nERROR: %s\n\r\n\r" USAGE  \
	"       Run \"s2s -h\" for help.\n\r",msg );
exit(0);
}

// ......................................................................
// in     file name
// out    1=exists | 0=doesn't
// desc   test to see if the file exists
// notes  .
// ......................................................................
int FileExists( char *f )
{
FILE	*h;

h=fopen(f,"rt");
if( h==NULL )
  return(0);

fclose(h);
return(1);
}

// ......................................................................
// in	  args!
// out    .
// desc   init some stuff
// notes  .
// ......................................................................
void Init( int argc, char *argv[] )
{
ParseArgs(argc,argv);
}

// ......................................................................
// in	  .
// out    .
// desc   makes the DOS batch file to build the VAB!
// notes  this is highly specific.  you may want to rewrite this chunk.
//
// notes  you'll note that it doesn't accept the main MOD file handle.
//        This is because this file does not depend upon reading the
//        MOD.
// ......................................................................
void MakeBatch( void )
{
char	OutFile[PREFIX_MAX+4],buf[PREFIX_MAX+128];
int	hand,i;
FILE	*fhand;

sprintf( OutFile,"%s.bat",Prefix );

if( Verbosity>VSILENT )
  printf( "Creating VAB-maker batch file\n" );

hand=creat(OutFile,S_IREAD|S_IWRITE);
if( hand==-1 )
  close(hand);
fhand=fopen( OutFile,"wt+" );
if( fhand==NULL )
  {
  sprintf( buf,"Can't create batch file (Code %d).\n",
	errno );
  ExitError( buf );
  }  // if( fhand==NULL )

fprintf( fhand,
	"@echo off\n"
	"rem\n"
	"rem This batch file was generated by %s v%s\n"
	"rem (c) 3/1998 Elliott Lee (tenchi@shell.jps.net)\n"
	"rem\n"
	"rem Run this to build your VAB file for use with\n"
	"rem my libraries.  You should have AIFF2VAG, MKVAB,\n"
	"rem and VABSPLIT in your path!\n"
	"rem\n"
	"\n"
	"rem Convert all those raw samples to VAGs, then rename\n"
	"rem the VAGs to make them shorter.\n",
	PROG_NAME,PROG_VER );

/* convert each sample */
for( i=0; i<Hdr.NumInstruments; i++ )
  {
  sprintf( buf,"%x",i );
  if( FileExists(buf) )
    {
    fprintf( fhand,
	"aiff2vag -%c -R %ld -E %s\n"
	"copy %s.VAG %x.\n"
	"del %s.VAG\n\n",
	LoopChar[i],C2Spd[i],buf,buf,i,buf
	);
    }  // if( FileExists(buf) )
  }  // for( i=0; i<Hdr.NumInstruments; i++ )

/* generate the VAB */
fprintf( fhand,
	"mkvab -f %s.def -o %s.vab",
	Prefix,Prefix
	);
for( i=0; i<Hdr.NumInstruments; i++ )
  {
  sprintf( buf,"%x",i );
  if( FileExists(buf) )
    {
    fprintf( fhand," %x",i );
    }  // if( FileExists(buf) )
  }  // for( i=0; i<Hdr.NumInstruments; i++ )
fprintf( fhand,
	"\n"
	"mkvab -r %s.vab -o %s.chk\n"
	"vabsplit %s.vab\n"
	"del %s.vab\n",
	Prefix,Prefix,Prefix,Prefix );

/* remove the samples to clean up! */
for( i=0; i<Hdr.NumInstruments; i++ )
  {
  sprintf( buf,"%x",i );
  if( FileExists(buf) )
    {
    fprintf( fhand,"del %x.\n",i );
    }  // if( FileExists(buf) )
  }  // for( i=0; i<Hdr.NumInstruments; i++ )

fprintf( fhand,
	"\n"
	"echo.\n"
	"dir %s.def\n"
	"dir %s.chk\n"
	"del %s.def\n"
	"del %s.chk\n"
	"echo.\n"
	"echo.WHAT TO DO NOW...\n"
	"echo.\n"
	"echo.  Check %s.chk to see if it is about the same size as the "
		"%s.def\n"
	"echo.  file.  If so, then everything should be okay and you can\n"
	"echo.  delete this file (%s.bat).  If things are NOT okay, then\n"
	"echo.  rerun " PROG_NAME " and step through this batch file.\n"
	"echo.\n"
	"echo.  Note:  This batch file just deleted the intermediary sample\n"
	"echo.  files.  You must run " PROG_NAME " again to generate them.\n"
	"echo.\n"
	"rem Done!\n",
	Prefix,Prefix,Prefix,Prefix,
	Prefix,Prefix,Prefix );

fclose(fhand);

if( Verbosity>VSILENT )
  printf( "\nWE'RE NOT QUITE DONE YET...\n"
	"You must now run \"%s\" to complete the process.\n",OutFile );
}

// ......................................................................
// in	  .
// out    .
// desc   makes the MKVAB definition file
// notes  .
// ......................................................................
void MakeDef( void )
{
char	OutFile[PREFIX_MAX+4],buf[PREFIX_MAX+128];
int	hand,i;
FILE	*fhand;

sprintf( OutFile,"%s.def",Prefix );

if( Verbosity>VSILENT )
  printf( "Creating MKVAB DEF file\n" );

hand=creat(OutFile,S_IREAD|S_IWRITE);
if( hand==-1 )
  close(hand);
fhand=fopen( OutFile,"wt+" );
if( fhand==NULL )
  {
  sprintf( buf,"Can't create DEF file (Code %d).\n",
	errno );
  ExitError( buf );
  }  // if( fhand==NULL )

fprintf( fhand,
	"VabHdr\n"
	"\tform = 'VABp'\n"
	"\tver = 0x7\n"
	"\tid = 0\n"
	"\tfsize = 0\n"
	"\tps = %d\n"
	"\tts = %d\n"
	"\tvs = %d\n"
	"\n",
	Instruments,Instruments,Instruments
	);

/* program attributes */
for( i=0; i<Hdr.NumInstruments; i++ )
  {
  sprintf( buf,"%x",i );
  if( FileExists(buf) )
    {
    fprintf( fhand,
	"ProgAtr %d\n"
	"\ttones = 1\n"
	"\tmvol = 127\n"
	"\tmpan = 64\n"
	"\n",
	InstrumentMap[i]
	);
    }  // if( FileExists(buf) )
  }  // for( i=0; i<Hdr.NumInstruments; i++ )

/* program description! */
for( i=0; i<Hdr.NumInstruments; i++ )
  {
  sprintf( buf,"%x",i );
  if( FileExists(buf) )
    {
    // These are all meant to make sure that the sample is defaulted
    // to max volume, center pan, maximum pitch bending range, and
    // virtually no ADSR envelope---this one is pretty flat.
    fprintf( fhand,
	"VagAtr %d 0\n"
	"\tprior = 127\n"
	"\tmode = %d\n"
	"\tvol = 127\n"
	"\tpan = 64\n"
	"\tcenter = 60\n"
	"\tshift = 0\n"
	"\tmin = 0\n"
	"\tmax = 127\n"
	"\tpbmin = 127\n"
	"\tpbmax = 127\n"
	"\tar = 127\n"
	"\tdr = 15\n"
	"\tsr = 0\n"
	"\trr = 31\n"
	"\tsl = 15\n"
	"\tprog = %d\n"
	"\tvag = %d\n"
	"\n",
	InstrumentMap[i],Reverb[i],InstrumentMap[i],InstrumentMap[i]+1
	);
    }  // if( FileExists(buf) )
  }  // for( i=0; i<Hdr.NumInstruments; i++ )


fclose(fhand);
}

// ......................................................................
// in	  handle to main file
// out    .
// desc   creates our own sequence file type (DMS)
// notes  See the beginning of this file for the sequence format.
// ......................................................................
void MakeSeq( int hand )
{
int	b;
int	base;
char	*buf;
int	destchan;
FILE	*dms;
PAT_ENT	e;
char	o;
int     octave,name,note;
char	OutFile[PREFIX_MAX+4],title[32];
long	ofs;
int	p,t;
int	readnote,readvol,readcmd;
int	row,chan;
unsigned int	patlen,bytesread;
long	posstart,posend,chunklen,numevents;
int	vol;
unsigned char	voladj[64+1];
float	fvol;

// make a quick volume-booster table!
if( VolumeCorrect )
  {
  for( vol=0; vol<=64; vol++ )
    {
    fvol = vol;
    fvol = fvol/64.0;
    t=VolumeCorrect;
    while( t>0 )
      { fvol = sqrt(fvol); t--; }
    fvol = fvol*64.0;
    voladj[vol]=(unsigned char)fvol;
    }  // for( vol=0; vol<=64; vol++ )
  }  // if( VolumeCorrect )

// status report...
if( Verbosity>VSILENT )
  printf( "Creating Digital Music Sequence (DMS) file..." );

sprintf( OutFile,"%s.dms",Prefix );

dms=fopen(OutFile,"wb+");
if( dms==NULL )
  ExitError( "Can't create DMS file!" );

//                     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  00 |   "DMSH"  | DMS Len   |VH|VL|Flags|Chans|Rows |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+

// We'll input the length later!
posstart=ftell(dms);
row=ROWS_PER_PAT;
chan=MAX_CHANNELS;
fprintf( dms,"DMSH____%c%c__",
	SEQVER_HI,SEQVER_LO );
fwrite( &chan,1,2,dms );
fwrite( &row,1,2,dms );

//                     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  10 |Or|Pt|In|Sp|Tm| ...Reserved...                 |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+

fprintf( dms,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",
	Hdr.NumOrders,Hdr.NumPatterns,Instruments+1,
	Hdr.InitSpeed,Hdr.InitTempo,

		       ////////////
		   ///////////////////
		////////////////////////
		///                   ///
		     0x61,     0x52,
		     0x5B,     0x50,

		0x55,               0x56,
		0x3E,0x46,0x46,0x45,0x2E
		  /*,0x35,0x3B,0xC4,*/
			      ///////
			       //////
				////
	);

//                     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  20 | Song title (31 chars max)                     |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  30 | Song title, cont'd                         |\0|
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+

for( t=0; t<32; t++ )
  title[t]=0;
strncpy( title,Hdr.SongName,31 );
fwrite( title,1,32,dms );

// now update the length, and move file pointer to ready position for
// the next chunk!
posend=ftell(dms);
chunklen=posend-posstart;
fseek(dms,posstart+4,SEEK_SET);
fwrite( &chunklen,1,4,dms );
fseek(dms,posend,SEEK_SET);

//                     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  40 |  "DMSO"   | Order Len | Order list.           |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+

// Now, this says it starts at position 0x40, but if we expand in the
// future, this will no longer be true!

posstart=ftell(dms);
fprintf( dms,"DMSO____" );

// Now, output the order list
ValidOrders=0;
for( t=0; t<Hdr.NumOrders; t++ )
  {
  o=Orders[t];
  fwrite(&o,1,1,dms);
  if( o<254 )
    ValidOrders++;
  }  // for( t=0; t<Hdr.NumOrders; t++ )
if( ValidOrders<1 )
  ExitError( "Your DMS had no orders!  Is your S3M file corrupt...?" );

// now update the length, and move file pointer to ready position for
// the next chunk!
posend=ftell(dms);
chunklen=posend-posstart;
fseek(dms,posstart+4,SEEK_SET);
fwrite( &chunklen,1,4,dms );
fseek(dms,posend,SEEK_SET);

//                     0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
//		  ?? |  "DMSP"   | Pat Len   | Pattern data.         |
//		     +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+

posstart=ftell(dms);
fprintf( dms,"DMSP____" );

// now process each pattern!
numevents=0;
for(p=0;p<Hdr.NumPatterns;p++)
  {
  // where is it?
  ofs = ParaPats[p];
  ofs = ofs<<4;

  // jump over to the data
  lseek( hand,ofs,SEEK_SET);

  // calculate the integer base for the notes!
  base=p*ROWS_PER_PAT;

  // length?
  // We'll subtract 2 bytes from the length total because the length
  // includes the length value itself!
  read(hand,&patlen,2);
  patlen-=2;

  // create our scratchpad!
  buf=malloc(patlen+1);
  if( buf==NULL )
    ExitError( "Can't create pattern buffer!\n" );

  // read in the packed pattern data to memory!
  bytesread=read(hand,buf,patlen);
  if( bytesread!=patlen && Verbosity>VSILENT)
    {
    printf( "\tWARNING: Couldn't read all %u bytes in pattern %d!\n",
	patlen,p );
    }  // if( bytesread!=patlen && Verbosity>VSILENT)

  // status messages
  if( Verbosity>VNORMAL )
    {
    printf( "    Pattern %d:\n"
	"\tOffset: 0x%0.8lx (%0.7ld)    Length: %u bytes\n",
	p,ofs,ofs,patlen );
    }  // if( Verbosity>VNORMAL )

  // clear the destination pattern!
  for( chan=0; chan<MAX_CHANNELS; chan++ )
    for( row=0; row<ROWS_PER_PAT; row++ )
      {
      Pat[chan][row].note=255;
      Pat[chan][row].instr=0;
      Pat[chan][row].vol=255;
      Pat[chan][row].cmd=255;
      Pat[chan][row].cmdinfo=0x00;
      }  // for( row=0; row<ROWS_PER_PAT; row++ )

  // unpack the pattern!
  row=0;
  b=0;
  while( b<patlen )
    {
    // read this first byte and figure out what to do based on that!
    if( buf[b]==0 )
      {
      // this row is done!  go to the next row!
      row++;
      chan=0;
      b++;
      }  // if( buf[b]==0 )
    else
      {
      // nope.  it's a real note!  let's get the destination channel:
      destchan=buf[b]&(0x1F);

      // okay, set the flags accordingly!
      if( buf[b]&(0x20) )
	readnote=1;
      else
	readnote=0;

      if( buf[b]&(0x40) )
	readvol=1;
      else
	readvol=0;

      if( buf[b]&(0x80) )
	readcmd=1;
      else
	readcmd=0;

      // on to the data...
      b++;

      // okay before we insert this data, make sure the channel and row
      // are in range!
      if( destchan>=MAX_CHANNELS )
	{
	sprintf( buf,"\nARGH!   Pattern %p exceeded the maximum number of channels %d.\n",
		(unsigned long)p,MAX_CHANNELS );
	ExitError( buf );
	}  // if( destchan>=MAX_CHANNELS )
      if( row>=ROWS_PER_PAT )
	{
	sprintf( buf,"\nARGH!   Pattern %p exceeded the maximum number of rows %d.\n",
		(unsigned long)p,ROWS_PER_PAT );
	ExitError( buf );
	}  // if( row>=ROWS_PER_PAT )

      // read byte?
      if( readnote )
	{
	Pat[destchan][row].note=buf[b];
	Pat[destchan][row].instr=buf[b+1];
	b+=2;
	}  // if( readnote )

      // read volume?
      if( readvol )
	{
	Pat[destchan][row].vol=buf[b];
	b++;
	}  // if( readvol )

      // read cmd/info?
      if( readcmd )
	{
	Pat[destchan][row].cmd=buf[b];
	Pat[destchan][row].cmdinfo=buf[b+1];
	b+=2;
	}  // if( readcmd )
      }  // else if( buf[b]==0 )
    }  // while( b<patlen )

  // now spit out the sequence info!
  for( row=0; row<ROWS_PER_PAT; row++ )
    {
    for( chan=0; chan<MAX_CHANNELS; chan++ )
      {
      // <time> = <note> <instrument> <command number>
      //          <command parameter>

      // Adjust instrument volumes---use default if a note exists...
      if( Pat[chan][row].vol==255 &&
	  Pat[chan][row].instr>0 &&
	  Pat[chan][row].instr<MAX_INST &&
	  InstrumentMap[Pat[chan][row].instr-1]!=-1)
	{
	Pat[chan][row].vol =
	  DefaultVol[Pat[chan][row].instr-1];
	}  // if( Pat[chan][row].vol==255 ... )

      // Make sure that this cell isn't blank.  No sense in
      // saving an event with nothing in it.
      if( Pat[chan][row].note!=255 ||
	  Pat[chan][row].instr!=0 ||
	  Pat[chan][row].vol!=255 ||
	  Pat[chan][row].cmd!=255 )
	{
	// translate the octave and note!
	if(Pat[chan][row].note<254)
	  {
	  // convert note?
	  octave=((Pat[chan][row].note>>4)&(0xf))+
	    OctaveAdjust[Pat[chan][row].instr-1];
	  name=Pat[chan][row].note&(0xf);
	  note=(octave*12)+name+NoteAdjust;
	  }  // if(Pat[chan][row].note<254)
	else
	  note=Pat[chan][row].note;

	// Pull the volume back inline in case it had flags on it.  Max is
	// 64 by the spec.
	if( Pat[chan][row].vol !=255 && Pat[chan][row].vol>64 )
	  Pat[chan][row].vol=64;

	// Correct the volume?
	if( VolumeCorrect && vol<=64 )
	Pat[chan][row].vol = voladj[Pat[chan][row].vol];

	// set the packed structure!
	// note: If the instrument in the pattern is 0, then that cell
	//       should have a 0 Instrument.  Otherwise, we decrease the
	//       instrument number to get its mapping, and then increase
	//       it back!  Screwed up?  You bet!  ^_^
	e.time=base+row;
	e.chan=chan;
	e.note=note;
	if( Pat[chan][row].instr==0 )
	  e.instr = 0;
	else
	  e.instr=InstrumentMap[Pat[chan][row].instr-1]+1;
	e.vol=Pat[chan][row].vol;
	e.cmd=Pat[chan][row].cmd;
	e.cmdinfo=Pat[chan][row].cmdinfo;

	//printf( "%5d: c%2x n%2x i%2x v%2x m%2x-%0.2x\n",
	//	e.time,e.chan,e.note,e.instr,e.vol,e.cmd,e.cmdinfo );

	fwrite( &e,1,8,dms );
	numevents++;
	}  // if( ... )
      }
    }

  // clean up after ourselves...
  free(buf);
  }  // for(p=0;p<Hdr.NumPatterns;p++)

// now update the length, and move file pointer to ready position for
// the next chunk!
posend=ftell(dms);
chunklen=posend-posstart;
fseek(dms,posstart+4,SEEK_SET);
fwrite( &chunklen,1,4,dms );
fseek(dms,posend,SEEK_SET);

fclose(dms);

printf( "Done!  (%ld events)\n",numevents );
}

// ......................................................................
// in	  number of args, pointer to args
// out    .
// desc   checks and parses the arguments list...
// notes  .
// ......................................................................
void ParseArgs( int argc, char *argv[] )
{
int	i;
char	buf[80];

strcpy( Prefix,"" );

for( i=1; i<argc; i++ )
  {
  // is an option/flag?
  if( argv[i][0]=='-' )
    {
    // It is!  It is!  But, make sure it's a single letter...
    if( argv[i][1]==0 )
      ExitError( "Options are in the format: -<letter>" );

    if( argv[i][2]!=0 )
      ExitError( "Options are only single letters." );

    // now figure out what to do with the option...
    switch( argv[i][1] )
      {
      case 'h': case 'H': case '?':  // help
	ShowHelp();
	break;
      case 'l': case 'L': // verbosity
	i++;
	Verbosity=atoi(argv[i]);
	if( Verbosity<0 || Verbosity>VHEAVY )
	  ExitError( "Verbosity can only be 0, 1, or 2!" );
	break;
      case 'n': case 'N': // adjust note
	i++;
	NoteAdjust = atoi(argv[i]);
	break;
      case 'o': case 'O': // normalize samples
	NormalizeInst=1;
	break;
      case 'p': case 'P': // prefix
	i++;
	if( strlen(argv[i])>PREFIX_MAX )
	  ExitError( "File prefix exceeds character limit." );

	strcpy(Prefix,argv[i]);
	break;
      case 'r': case 'R': // resample
	Resample = 1;
	i++;
	ResampleRate = atol( argv[i] );
	if( ResampleRate<RESAMP_LOW )
	  {
	  sprintf( buf,"Resampling rate too low.  Must be at least %ld.",
	  RESAMP_LOW );
	  ExitError( buf );
	  }  // RESAMP_LOW
	break;
      case 'v': case 'V': // correct the volume intensity
	VolumeCorrect++;
	break;
      default:
	ExitError( "Unknown option!  Check your syntax." );
	break;
      }  // switch( argv[i][1] )
    }  // if( argv[i][0]=='-' )
  else
    {
    // Nope.  Must be the input filename.
    if( Infile!=NULL )
      ExitError( "Two input files?!  Check your syntax..." );

    Infile=argv[i];
    }  // else if( argv[i][0]=='-' )
  }  // for( i=1; i<argc; i++ )

if( i>argc )
  ExitError( "Last option missing its value!" );

// make sure the infile isn't blank!
if( Infile==NULL )
  ExitError( "Missing input file!" );

// make sure input file exists!
if( !FileExists(Infile) )
  {
  // Maybe the user forgot to add the S3M to it!
  // Check for an extension.
  if( strstr(Infile,".")!=NULL )
    ExitError( "Input file doesn't exist!" );

  // No, the user really did forget the extension!  Splice one on...
  strcpy( &Infile[strlen(Infile)],".S3M" );

  // Check again..
  if( !FileExists(Infile) )
    ExitError( "Input file doesn't exist!" );
  }  // if( !FileExists(Infile) )

// if prefix isn't set, use the Infile name!
if( Prefix[0]==0 )
  {
  strcpy( Prefix,Infile );

  // now remove the extension!
  for( i=0; i<strlen(Prefix); i++ )
    {
    if( Prefix[i]=='.' )
      Prefix[i]=0;
    }  // for( i=0; i<strlen(Prefix); i++ )
  }  // if( Prefix[0]==0 )
}

// ......................................................................
// in	  file handle
// out    .
// desc   parse the S3M header
// notes  the header has a predefined format.
// ......................................................................
void ParseHeader( int hand )
{
char		MagicWord[5];
char		buf[128];

read(hand,&Hdr,sizeof(S3MHEADER));

// make sure that the 0x1A exists
if( Hdr.Eof!=(0x1a) )
  ExitError( "File not valid S3M!  (Missing 0x1A in header.)" );

// make sure it's an S3M module
if( Hdr.Type!=16 )
  ExitError( "File not valid S3M!  (Type not 0x10.)" );

// check for magic word
strncpy(MagicWord,Hdr.MagicWord,4);
MagicWord[4]=0;
if( strcmpi(MagicWord,"SCRM")!=0 )
  {
  sprintf( buf,"File not valid S3M!  (Magic Word not \"SCRM\".)\n"
	"I got \"%s\".",MagicWord );
  ExitError( buf );
  }  // if( strcmpi(MagicWord,"SCRM")!=0 )

// title
strncpy(Title,Hdr.SongName,28);
Title[28]=0;

// set stereo
if( Hdr.MasterVol&(0x80) )
  Stereo=1;
else
  Stereo=0;
MasterVol=Hdr.MasterVol&(0x7f);

// check tracker type
switch( Hdr.TrackerInfo )
  {
  case 0x1300: Tracker=0; break;
  case 0x1301: Tracker=1; break;
  case 0x1303: Tracker=2; break;
  case 0x1320: Tracker=3; break;
  default:     Tracker=4; break;
  }  // switch( Hdr.TrackerInfo )

// how many instruments
if( Hdr.NumInstruments>MAX_INST )
  {
  sprintf( buf,"Sorry, too many instruments (%d).  Only %d allowed.  Remember that\n"
	"       comments DO count as instruments!",Hdr.NumInstruments,MAX_INST );
  ExitError( buf );
  }  // if( Hdr.NumInstruments>MAX_INST )
if( Hdr.NumInstruments<1 )
  {
  ExitError( "You had no instruments!  Your S3M file may be corrupt...?" );
  }  // if( Hdr.NUmInstruments<1 )

// we have panning?  we'll load it in!
if( Hdr.DefaultPan==252 )
  DefaultPan=1;
else
  DefaultPan=0;

// Copy the orders over.  Do a check first for the amount.
// Accorrding to ST 3.21's TECH.DOC, the number of Orders must
// be even.  This is probably due to making it word-aligned.
// But since we really don't care about making things word-aligned,
// I ignored it.  Uncomment if necessary.
//
// if( Hdr.NumOrders%2 )
//   Hdr.NumOrders++;
if( Hdr.NumOrders>MAX_ORDERS )
  {
  sprintf( buf,"Sorry, too many orders (%d).  Only %d allowed.",
	Hdr.NumOrders,MAX_ORDERS );
  ExitError( buf );
  }  // if( Hdr.NumOrders>MAX_ORDERS )
if( Hdr.NumOrders<1 )
  {
  ExitError( "You had no orders!  Your S3M file may be corrupt...?" );
  }  // if( Hdr.NumOrders<1 )
lseek(hand,OFS_ORDERS,SEEK_SET);
read(hand,Orders,Hdr.NumOrders);

// the LAST order should be a "---" (255)
if( Orders[Hdr.NumOrders-1]!=255 && Verbosity>VSILENT )
  {
  // warn the user!
  WarningText( "Last order was not a \"---\"!  "
	"Your file may be corrupted." );
  }  // if( Orders[Hdr.NumOrders-1]!=255 )

// Copy the instrument (sample) para-pointers over.  We'll also
// do a check to make sure that we don't overflow the number!
// The length of the instrument para-pointers is NumInstruments*2.
if( Hdr.NumInstruments>MAX_INST )
  {
  sprintf( buf,"Sorry, too many instruments (%d).  Only %d allowed.",
	Hdr.NumInstruments,MAX_INST );
  ExitError( buf );
  }  // if( Hdr.NumInstruments>MAX_INST )
lseek(hand,OFS_ORDERS+Hdr.NumOrders,SEEK_SET);
read(hand,ParaInstruments,(Hdr.NumInstruments)*2);

// Copy the pattern paragraph pointers over.
if( Hdr.NumPatterns>MAX_PATS )
  {
  sprintf( buf,"Sorry, too many patterns (%d).  Only %d allowed.",
	Hdr.NumPatterns,MAX_PATS );
  ExitError( buf );
  }  // if( Hdr.NumInstruments>MAX_INST )
if( Hdr.NumPatterns<1 )
  {
  ExitError( "You had no patterns!  Your S3M file may be corrupt...?" );
  }  // if( Hdr.NumPatterns<1 )
lseek(hand,(long)OFS_ORDERS+(long)Hdr.NumOrders+
	((long)Hdr.NumInstruments*2l),SEEK_SET);
read(hand,ParaPats,Hdr.NumPatterns*2);
}

// ......................................................................
// in	  .
// out    .
// desc   process input file
// notes  .
// ......................................................................
void ProcessFiles( void )
{
int	hand;

hand=open(Infile,O_RDONLY|O_BINARY);
if( hand==-1 )
  ExitError( "Cannot open input file." );

// how big is it?
lseek(hand,0,SEEK_END);
FileLen=(unsigned long)tell(hand);
lseek(hand,0,SEEK_SET);

ParseHeader(hand);
Diagnostic();
ProcessInst(hand);
MakeSeq(hand);
close(hand);

MakeDef();
MakeBatch();
}

// ......................................................................
// in	  main module file handle
// out    .
// desc   chunks on the instruments
// notes  All instruments will be reverbed by the Yaroze SPU, unless
//	  specified.  To disable reverb for a particular instrument,
//	  include "[r]" in the sample name!
// ......................................................................
void ProcessInst( int hand )
{
int		bit16;
unsigned char	*buf,*bufx;
unsigned int    bytes2read,bytesread;
long		numsamps;
char		Fname[13];
int		HandTemp,HandWave;
int		i,j;
S3IHEADER	Inst;
char		MagicWord[5];
long		OfsHeader,OfsData,l;
char		OutFile[PREFIX_MAX+4];
char		*TempFile="__TEMP__.!!~";
float		pos,velocity;
unsigned int	*shrinker,intacc;
float		accumulator,rise,fmidval;
unsigned int	endpoints[2],midval;
long		a,b;

// create our working buffer.
buf=malloc(SIZE_WORKBUF*sizeof(char));
if( buf==NULL )
  ExitError( "Cannot allocate working buffer memory!" );
bufx=malloc(SIZE_WORKBUF*sizeof(int));
if( bufx==NULL )
  ExitError( "Cannot allocate working buffer memory!" );

// walk thru all instruments
Instruments=0;
for( i=0; i<Hdr.NumInstruments; i++ )
  {
  OfsHeader=ParaInstruments[i]<<4;
  InstrumentMap[i]=-1;

  // form the output file
  sprintf( OutFile,"%x.",i );

  // grab that header
  lseek(hand,OfsHeader,SEEK_SET);
  read(hand,&Inst,sizeof(S3IHEADER));

  if( Verbosity>VSILENT )
    { printf( "Instrument [%0.3d]: ",i ); }

  // is this a valid instrument?  check the magic word.
  strncpy(MagicWord,Inst.MagicWord,4);
  MagicWord[4]=0;
  if( strcmpi(MagicWord,"SCRS")!=0 )
    {
    printf( "Invalid instrument! (%s)\r\n",MagicWord );
    continue;
    }  // if( strcmpi(MagicWord,"SCRS")!=0 )

  // check the file type
  switch(Inst.Type)
    {
    case 0:
      // no instrument here.  just text!
      printf( "\"%s\" (Text)\r",Inst.SampleName );
      if( Verbosity>VNORMAL )
	printf( "\n" );
      continue;
    case 1:
      // this is okay...
      break;
    case 2: case 3:
      if( Verbosity>VNORMAL )
	printf( "\n\r\tAdlib instruments not supported.  Skipped.\n\r" );
      continue;
    default:
      if( Verbosity>VNORMAL )
	printf( "\n\r\tUnknown instrument type (%d).  Skipped.\n\r",
	  Inst.Type );
      continue;
    }  // switch(Inst.Type)

  // process the filename.  the NULL is not included in the header!
  memcpy(Fname,Inst.Filename,12);
  Fname[12]=0;

  if( Verbosity>VNORMAL )
    printf( "\"%s\" (%s) => \"%s\" ",Inst.SampleName,
	Inst.Filename,OutFile );

  // deny reverb?
  //
  // The number '4' comes from the Yaroze spec.  Don't ask what it really
  // means...
  if( strstr(Inst.SampleName,NoReverb)!=NULL )
    Reverb[i]=4;
  else
    Reverb[i]=0;

  // what bit size?
  if( Inst.Flags&FLAG_BITSIZE )
    bit16=1;
  else
    bit16=0;

  if( Verbosity>VNORMAL )
    printf( "(%db)",8<<bit16 );

  // get the offset of the sample.
  OfsData = (unsigned char)(Inst.MemSeg[0]);
  OfsData = (OfsData<<8)|(unsigned char)(Inst.MemSeg[2]);
  OfsData = (OfsData<<8)|(unsigned char)(Inst.MemSeg[1]);
  OfsData = OfsData<<4;

  if( OfsData==0 || OfsData>FileLen )
    {
    if( Verbosity>VSILENT )
      printf( "\n\r\tSample offset screwed up (%lx).  "
	"Instrument skipped.\n\r",
	OfsData );
    continue;
    }  // if( OfsData==0 || OfsData>FileLen )

  if( Verbosity>VNORMAL )
    {
    printf( "\n\r\tHeader Addr=%-0.8lx ",OfsHeader );
    printf( "Data Addr=%-0.8lx ",OfsData );
    }  // if( Verbosity>VNORMAL )

  // length?
  if( Inst.Length==0 )
    {
    printf( "\"%s\" (Blank)\r",Inst.SampleName );
    if( Verbosity>VNORMAL )
      printf( "\n" );
    continue;
    }  // if( Inst.Length<1 )
  if( Verbosity>VNORMAL )
    {
    printf( "Size=%ld bytes (0x%lx)\r\n",Inst.Length,Inst.Length );
    }  // if( Verbosity>VNORMAL )

  // save some header data for later
  C2Spd[i]=Inst.C2Spd;

  OctaveAdjust[i]=0;
  if( NormalizeInst )
    {
    printf( "\tNormalizing %d from %ld ",i,C2Spd[i] );
    while( C2Spd[i]<OCTNORM_LOW || C2Spd[i]>=OCTNORM_HI )
      {
      if( C2Spd[i]<OCTNORM_LOW )
	{
	C2Spd[i] = C2Spd[i]*2;
	OctaveAdjust[i]--;
	}  // if( C2Spd[i]<OCTNORM_LOW )
      if( C2Spd[i]>=OCTNORM_HI )
	{
	C2Spd[i] = C2Spd[i]/2;
	OctaveAdjust[i]++;
	}  // if( C2Spd[i]>OCTNORM_HI )
      }  // while( C2Spd[i]<OCTNORM_LOW || C2Spd[i]>OCTNORM_HI )
    printf( " -> %ld Hz (%d)\n",C2Spd[i],OctaveAdjust[i] );
    }  // if( NormalizeInst )

  // set the default volume!
  DefaultVol[i]=Inst.Volume;

  // is this a looped sample?  If so, the LoopChar will be 'L'.  If
  // not, then '1'.
  if( Inst.Flags&FLAG_LOOP )
    {
    LoopChar[i]='L';

    // we'll also check to see if the length of the number of samples
    // is a multiple of 28!
    if( bit16 )
      numsamps=Inst.Length>>1;
    else
      numsamps=Inst.Length;

    if( numsamps%28!=0 && Verbosity>VSILENT )
      {
      if( Verbosity==VNORMAL )
	printf( "\r\n" );
      printf( "\tWARNING: Number of samples in instrument #%d "
	"isn't a multiple\r\n"
	"\tof 28!  Shorten it to %ld to avoid obnoxious clicking.\r\n",
	i,numsamps-(numsamps%28) );
      }  // if( numsamps%28!=0 && Verbosity>VSILENT )
    }  // if( Inst.Flags&FLAG_LOOP )
  else
    LoopChar[i]='1';

  // okay, looks good to me.  copy the wave output to a file.
  HandWave=creat(OutFile,S_IREAD|S_IWRITE);
  if( HandWave!=-1 )
    close(HandWave);
  HandWave=open(OutFile,O_RDWR|O_BINARY);
  if( HandWave==-1 )
    {
    if( Verbosity>VSILENT )
      {
      printf( "\tERROR: Can't write to output file (Code %d)!\r\n",
	errno );
      }  // if( Verbosity>VSILENT )
    continue;
    }  // if( HandWave==-1 )

  // seek to the position where we begin copying
  lseek(hand,OfsData,SEEK_SET);

  // copy!
  if( bit16 )
    {
    // this is already 16-bit sampling.
    for( l=0; l<(Inst.Length<<1); l+=SIZE_WORKBUF )
      {
      if( l+SIZE_WORKBUF>(Inst.Length<<1) )
	bytes2read=(unsigned)((Inst.Length<<1)-l);
      else
	bytes2read=SIZE_WORKBUF;

      bytesread=read(hand,buf,bytes2read);

      // change the sign bit
      for( j=1; j<bytesread; j+=2 )
	buf[j] ^= 0x80;

      write(HandWave,buf,bytesread);
      }  // for( l=0; l<(Inst.Length<<1); l+=SIZE_WORKBUF )
    }  // if( bit16 )
  else
    {
    // this is already 16-bit sampling.  no need to transform.
    for( l=0; l<Inst.Length; l+=SIZE_WORKBUF )
      {
      if( l+SIZE_WORKBUF>Inst.Length )
	bytes2read=(unsigned)(Inst.Length-l);
      else
	bytes2read=SIZE_WORKBUF;

      bytesread=read(hand,buf,bytes2read);

      // now expand the bytes read into the working buffer, changing the
      // sign bit, too
      for( j=0; j<bytesread; j++ )
	{
	bufx[j<<1]    =0;
	bufx[(j<<1)+1]=buf[j]^(0x80);
	}  // for( j=0; j<bytesread; j++ )

      write(HandWave,bufx,bytesread<<1);
      }  // for( l=0; l<Inst.Length; l+=SIZE_WORKBUF )
    }  // else if( bit16 )

  // now just iterate thru the file, copying stuff.
  close(HandWave);

  // now, do we resize the sample?
  if( Resample && ResampleRate!=C2Spd[i] )
    {
    // we're going to open the file we just wrote and strech the wave!
    // First, determine that we can open the file and that we can open
    // the temp file.
    HandTemp=creat(TempFile,S_IWRITE|S_IREAD);
    if( HandTemp<0 )
      {
      ExitError(
	"Could not create temp file for resampling your instruments!\n"
	"Check that you have enough disk space!\n"
	);
      }  // if( HandTemp<0 )
    HandWave=open(OutFile,O_RDONLY|O_BINARY);
    if( HandWave<0 )
      ExitError( "Couldn't re-open the instrument files for resampling!" );

    // Okay.  Both open and ready.

    // Calculate the velocity (length of the new sample width in comparison
    // to the old sample) for each instrument.
    pos=0;
    velocity=((float)C2Spd[i])/((float)ResampleRate);

    // make sure the velocity is less than the size of our working buffer!
    // doubtful, but possible... :)
    if( (velocity+1.0)>(float)(SIZE_WORKBUF*sizeof(int)) )
      {
      ExitError( "Your resampling rate was too high and would have\n"
	"overflowed the working buffers!  Lower it and try again." );
      }  // if( (velocity+1.0)>(float)(SIZE_WORKBUF*sizeof(int)) )

    // get the number of 16-bit samples in the file.  I don't trust the
    // Inst.Length...  :(
    numsamps = lseek(HandWave,0,SEEK_END)/2l;

    if( Verbosity>VNORMAL )
      {
      printf(
	"\tResampling inst %d.  Expansion rate: %0.2f\n",
	i,velocity );
      }  // if( Verbosity>VNORMAL )

    // Now, are we expanding or shrinking?
    if( velocity<1.0 )
      {
      // exapaaaaaaand!!!!!
      if( Verbosity>VSILENT )
	printf( "\n\tExpanding sample %d from %ld Hz to %ld Hz (%.2f%%)\n",
	  i,C2Spd[i],ResampleRate,100.0/velocity );

      // this requires interpolation!
      while( (long)pos < numsamps )
	{
	// what are the integer values of the endpoints?
	a=(long)pos;
	b=a+1l;

	// okay seek and then get the values of the endpoints!  Remember
	// there are 2 16-bit endpoints.
	lseek( HandWave,a*2l,SEEK_SET );
	read( HandWave,endpoints,4 );

	// flip the sign bits.  REMEMBER: it's a 16-bit value!
	endpoints[0] ^= (0x8000);
	endpoints[1] ^= (0x8000);

	// cool.  Now we can determine the slope!
	rise = (float)((long)endpoints[1]-(long)endpoints[0]);

	// now that we have our values, we can interpolate between these
	// endpoints (linearly) until we exceed the bounds.
	while( (long)pos < b )
	  {
	  // what's the midpoint's value?  (should be positive)
	  fmidval = ((float)endpoints[0]) + ((pos-((float)a)) * rise);

	  // convert to integer for storage;
	  midval = (unsigned int)fmidval;

	  // flip its sign bit (16-bit!)
	  midval ^= (0x8000);

	  // save to disk
	  _write( HandTemp,&midval,2 );

	  // advance to next position
	  pos += velocity;
	  }  // while( (long)pos < b )
	}  // while( a<numsamps )
      }  // if( ResampleRate<Inst.C2Spd )
    else if( velocity>1.0 )
      {
      // SHRINK!

      if( Verbosity>VSILENT )
	printf( "\n\tCompressing sample %d from %ld Hz to %ld Hz (%.2f%%)\n",
	  i,C2Spd[i],ResampleRate,100.0/velocity );

      // set our pointer
      shrinker = (unsigned *)bufx;

      while( (long)pos < numsamps )
	{
	// reset the accumulator
	accumulator=0;

	// Grab all the bytes (which will be integers) between the
	// current integer position and the next integer position.
	// First seek to the proper position in the file then read.
	lseek( HandWave,((long)pos)*2l,SEEK_SET );
	bytesread=read( HandWave,bufx,((unsigned)velocity)*2u );

	// Now that we've gotten the data, we're going to average them
	// all out!  This is done by adding up all the integers and
	// then dividing by the number of things read.  Remember to
	// divide the bytes by 2 to get the number of 16-bit integers!
	//
	// note: We have to flip the sign bit along the way.
	bytesread = bytesread/2;

	for( j=0; j<bytesread; j++ )
	  accumulator += (float)(shrinker[j]^(0x8000));

	accumulator = accumulator / (float)bytesread;

	// convert the averaged value of the accumulator to integer.
	a = accumulator;
	intacc = (unsigned)a;

	// flip the sign bit back
	intacc ^= (0x8000);

	// now write the accumulator's value out to disk!
	_write( HandTemp,&intacc,2 );

	// and advance to the next sample section
	pos += velocity;
	}  // while( (long)pos < numsamps )
      }  // else if( velocity>1.0 )

    close(HandWave);
    close(HandTemp);

    // Okay.  The instrument has been resampled!  Now just copy it
    // back!
    HandWave=creat(OutFile,S_IWRITE|S_IREAD);
    if( HandWave<0 )
      ExitError( "Could not recreate output wave file after resampling!" );
    HandTemp=open(TempFile,O_RDONLY|O_BINARY);
    if( HandTemp<0 )
      ExitError( "Couldn't re-open the temp file after resampling!" );

    // copy the entire file byte-for-byte
    bytesread=read(HandTemp,buf,SIZE_WORKBUF);
    while( bytesread )
      {
      _write(HandWave,buf,bytesread);
      bytesread=read(HandTemp,buf,SIZE_WORKBUF);
      }  // while( bytesread )

    close(HandWave);
    close(HandTemp);

    // Get rid of the temp file!
    unlink( TempFile );

    // Save the new speed!
    C2Spd[i]=ResampleRate;
    }  // if( Resample )

  // map this instrument to the new VAG instrument!
  InstrumentMap[i]=Instruments;

  // update the counters
  Instruments++;

  // pretty printing
  if( Verbosity>VSILENT )
    printf( "\r" );
  if( Verbosity>VNORMAL )
    printf( "\n" );
  }  // for( i=0; i<Hdr.NumInstruments; i++ )
if( Instruments<1 )
  ExitError( "You had no valid instruments.  Is your S3M file corrupt...?" );

if( Verbosity>VSILENT )
  printf( "\n" );

free(buf);
free(bufx);
}

// ......................................................................
// in	  .
// out    .
// desc   show help and then quit
// notes  .
// ......................................................................
void ShowHelp( void )
{
printf( "\n"
	PROG_NAME " Converter v" PROG_VER "\n"
	"(c) 1998 Elliott Lee (tenchi@netmagic.net)\n\n"
	USAGE
	"Options:\n"
	"  -h         See this Help page.\n"
	"  -l <level> Set verbosity level: 0=silent, 1=normal, 2=heavy.\n"
	"  -n <num>   Adjust ALL notes <num> semitones.  <num>=pos/neg int.\n"
	"  -o         Normalize all samples to %ld-%ld Hz.\n"
	"  -p <name>  Set the output file prefix.  Default is your S3M name.\n"
	"  -r <freq>  Resample instruments to <freq>.\n"
	"  -v         Volume correction.\n"
	"\n"
	"Tips & Notes:\n"
	"  +  8-bit samples are automatically converted to 16-bit.\n"
	"  +  Looped samples will be looped over the ENTIRE sample.  The Start/End Loop\n"
	"     points are set to the beginning/end!\n"
	"  +  Use \"-r 22050\" if the whole song sounds completely out of tune.\n"
	"  +  Use a combination of -o AND -r to squash instrument sizes!\n"
	"  +  Use -v if your song is too quiet---the PSX volumes are not as strong\n"
	"\n",
	OCTNORM_LOW,OCTNORM_HI
	);
exit(0);
}

// ......................................................................
// in	  message
// out    .
// desc   prints warning message
// notes  .
// ......................................................................
void WarningText( char *msg )
{
printf( "WARNING: %s\n",msg );
}

// ......................................................................
// in	  number of args, pointer to args
// out    .
// desc   main!
// notes  .
// ......................................................................
void main( int argc, char *argv[] )
{
Init(argc,argv);
ProcessFiles();
}