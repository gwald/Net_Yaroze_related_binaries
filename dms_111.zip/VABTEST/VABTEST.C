// program:     VAB Tester
// mainfile:    vabtest.c
//
// file:        vabtest.c
// created:     31 Mar 1998
// author:	Elliott Lee
// company:	Protocol Software
// e-mail:	tenchi@netmagic.net
// url:		http://www.netmagic.net/~tenchi
//
// copyright:   (C) 1998 Elliott Lee
// copyright:   Portions (C) 1998 Sony Computer Entertainment Inc.
//
// description: Loads a VAB and lets you play back specific samples
//		in that VAB

// ......................................................................
// GENERAL INCLUDES
// ......................................................................
#include <libps.h>
#include "../library/padstuff.c"
#include "../library/prnstuff.c"

// ......................................................................
// CONSTANTS
// ......................................................................

#define OT_LENGTH		(2)	  
		// size of ordering table: 2 << OT_LENGTH
		// i.e.	16384 levels of z resolution
#define PACKETMAX		(1000)
#define PACKETMAX2              (PACKETMAX*24)
		// GPU packet space
#define         VBADDR          0x80100000
#define         VHADDR          0x800d0000
                // VAB stuff

// ......................................................................
// GLOBALS
// ......................................................................
GsOT		WorldOrderingTable[2];
		// Ordering Table handlers
GsOT_TAG        zSortTable[2][1<<OT_LENGTH];   
		// actual Ordering Tables themselves							
PACKET		GpuOutputPacket[2][PACKETMAX2];
		// GPU packet work area
int		Page=0;
		// Current display page
char            *ProgName="VAB Tester",
                *ProgVer="1.0.0";
int		VabID;
u_long		PadStatus;

// ......................................................................
// FUNCTION PROTOTYPES
// ......................................................................

// ......................................................................
// in:          -
// out:         -
// desc:	bye bye
// note:	-
// ......................................................................
void CleanUp( void )
{
// clean up
SsVabClose(VabID);
ResetGraph(3);
}

// ......................................................................
// in:          -
// out:         -
// desc:        wait and flip video pages
// note:	-
// ......................................................................
void FlipPage( void )
{
  // find which buffer is active
  // set address for GPU scratchpad area
  // clear the ordering table
  Page = GsGetActiveBuff();
  GsSetWorkBase( (PACKET*)GpuOutputPacket[Page]);
  GsClearOt(0, 0, &WorldOrderingTable[Page]);

  // wait for end of drawing
  // wait for V_BLANK interrupt
  DrawSync(0);
  VSync(0);

  // swap double buffers
  GsSwapDispBuff();

  // register clear-command: clear to black
  // register request to draw ordering table
  GsSortClear(0x0, 0x0, 0x60,&WorldOrderingTable[Page]);
  GsDrawOt(&WorldOrderingTable[Page]);

  // Clear our work area.
  PrintClear(0);
}

// ......................................................................
// in:          -
// out:         -
// desc:	init routines
// note:	-
// ......................................................................
void Init( void )
{
printf( "\n%s v%s\n(c) 1998 Elliott Lee, tenchi@netmagic.net\n",
        ProgName,ProgVer );
printf( "Portions (c) 1998 Sony Computer Entertainment, Ltd.\n\n" );

// NTSC mode
SetVideoMode( MODE_NTSC );      

// non-interlace, use GsGPU offset
ResetGraph(0);
GsInitGraph(320 ,240, GsOFSGPU|GsNONINTER, 1, 0);                
GsDefDispBuff(0, 0, 0, 256);

// set up the ordering table handlers
WorldOrderingTable[0].length = OT_LENGTH;
WorldOrderingTable[1].length = OT_LENGTH;
WorldOrderingTable[0].org = zSortTable[0];
WorldOrderingTable[1].org = zSortTable[1];

// set up the controller pad
PadInit();

// set up print stuff
PrintInit(960,256,0,36,28,8,16);

// load sounds
VabID = SsVabTransfer( (u_char*)VHADDR, (u_char*)VBADDR, -1, 1 );
if( VabID<0 )
  {
  printf( "\nERROR: VAB couldn't be loaded!  Code %d.\n\n",VabID );
  exit(1);
  }  // if( VabID<0 )
SsSetMVol( 127,127 );
}

// ......................................................................
// in:          -
// out:         -
// desc:	main
// note:	-
// ......................................................................
int main (void)
{
#define	rows	4

int	buttondown=0;
char	buf[256];
int	Program=0;
int	Tone=0;
int	Note=48;
int	Volume=127;
int	Repeatclock=0;
int	Row=0;
int	CurType=0;
int	Clock=0;
int	MsgClock=0;
char	Msg[80];
int	inc;
int	lastvoice;

// Initialize
Init();

PadStatus = PadGet();
while( !(PadStatus & PAD1SELECT) )
  {
  FlipPage();
  PadStatus = PadGet();

  if( PadStatus )
    Repeatclock++;
  if( PadStatus && (!buttondown || (Repeatclock>30 && Clock%2==0)) )
    {
    if( PadStatus & PAD1UP )
      {
      Row--;
      if( Row<0 ) Row=rows-1;
      }
    if( PadStatus & PAD1DOWN )
      {
      Row++;
      if( Row>=rows ) Row=0;
      }
    if( PadStatus & (PAD1LEFT|PAD1RIGHT) )
      {
      if( PadStatus&PAD1LEFT )
        inc=-1;
      else
        inc=+1;

      switch( Row )
        {
        case 0: // program
	  Program+=inc;
          if( Program<0 ) Program=128;
          if( Program>128 ) Program=0;
          break;
        case 1: // tone
	  Tone+=inc;
          if( Tone<0 ) Tone=2048;
          if( Tone>2048 ) Tone=0;
          break;
	case 2: // note	  
	  Note+=inc;
          if( Note<0 ) Note=96;
          if( Note>96 ) Note=0;
	case 3: // vol
	  Volume+=inc;
          if( Volume<0 ) Volume=0;
          if( Volume>127 ) Volume=127;
        }
      }
    if( PadStatus & PAD1CIRCLE )
      {
      lastvoice=SsUtKeyOn( VabID,Program,Tone,Note,0,Volume,Volume );  
      sprintf( Msg,"Key On: P%d T%d N%d V%d",Program,Tone,Note,lastvoice );
      MsgClock=60;
      }
    if( PadStatus & PAD1TRI )
      {
      SsUtKeyOff( lastvoice,VabID,Program,Tone,Note );  
      sprintf( Msg,"(Keyed off)" );
      MsgClock=60;
      }
    if( PadStatus & PAD1CROSS )
      {
      SsUtAllKeyOff( 0 );  
      sprintf( Msg,"(Keyed off)" );
      MsgClock=30;
      }
    buttondown=1;
    }
  if( PadStatus==0 )
    {
    buttondown=0;
    Repeatclock=0;
    }

  PrintClear(0);
  PrintXY(1,1,
	"VAB TESTER!        (c) 1998 E. Lee\n" \
	"                                  \n" \
	"Up/Dn selects menu option, Lf/Rt  \n" \
	"changes value, O plays tone, X    \n" \
	"stops all, /\\ stops last voice,  \n" \
        "SELECT quits.                     \n" \
	"                                  \n" \
	"         Program                  \n" \
	"         Tone                     \n" \
	"         Note (48=Middle C)       \n" \
	"         Volume                   \n"
	);
  sprintf( buf,"%d\n%d\n%d\n%d",Program,Tone,Note,Volume );
  PrintXY( 6,8,buf );
  switch( CurType )
    {
    case 0: PrintXY( 2,Row+8,"-->" ); break;
    case 1: PrintXY( 2,Row+8,"->" ); break;
    case 2: PrintXY( 2,Row+8,">" ); break;
    case 3: PrintXY( 2,Row+8,"->" ); break;
    }

  Clock++;
  if( Clock%20==0 )
    CurType=(CurType+1)%4;
  if( MsgClock>0 )
    {
    MsgClock--;
    PrintXY( 1,24,Msg );
    }

  GsDrawOt(&WorldOrderingTable[Page]);
  PrintFlush();
  }  // while( !(PadStatus & PAD1SELECT) )

CleanUp();
return(0);
}

// [end]
