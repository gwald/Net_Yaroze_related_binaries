// program:     Print helpers.
// mainfile:    prnstuff.c
//
// file:        prnstuff.c
// version:     1.1.0
// created:     27 Jan 1998
// updated:	11 May 1998
// author:      Elliott Lee
// company:     Protocol Software
// e-mail:      tenchi@shell.jps.net
// url:         http://www.jps.net/tenchi
//
// copyright:   (C) 1998 Elliott Lee
// copyright:   Portions (C) 1998 Sony Computer Entertainment Inc.
//
// description: Text printing helper routines.  A local buffer is set up
//              and a set of print routines below allow you to output
//              text to it!  But they are all slow.
//
//              This was created to solve text placement problems.
//              It is partially based off of the MITEXT.ZIP demo program.
//
// warnings:    The following routines use the FntOpen() function and
//              handle all the print stream stuff.  Thus, you either
//              use this code or you don't.
//
// examples:    You should call the following functions in this order:
//
//                1. PrintInit(960,256,0,34,26,0,0);
//                2. PrintClear(0);
//                3. PrintXY(1,1,"Hello World!");
//                4. PrintFlush();
//                5. go back to step 2...
//
//              PrintInit() sets up things by calling the PSX library
//              functions FntInit() and FntLoad().  PrintClear() cleans
//              the local buffer in preparation for printing.  PrintXY()
//              does the text writing and placement.  Finally,
//              PrintFlush() moves the contents of our buffer into the
//              real print stream.

// ......................................................................
// HEADER FILES
// ......................................................................

#include "prnstuff.h"

// ......................................................................
// FUNCTIONS
// ......................................................................

// ......................................................................
// in:    character to clear with*
// out:   -
// desc:  Clears the print buffer.
// notes: *must be a character in the ASCII range 33-126.  All other
//        characters will be interpreted as spaces.
//
// notes: this is a rather slow function.  The optimal way to clear this
//        buffer (if all bytes are contiguous) is to get the start
//        address and paste x*y characters in a row.  Unfortunately we
//        calculate the offset every loop iteration!  What a waste...
//
//        That optimization may be added eventually if speed does become
//        an issue.
// ......................................................................
void PrintClear( char c )
{
int     x,y,cnt;
char    *ptr;

// if outside the printable range, turn into a space char       
if( c<32 || c>126 )
  c=32;

// make every entry into the specified character...
//
// To optimize you would write something like:
// 
//   char *bufptr;
//   int  iters;
//
//   bufptr=PrintStuff_Matrixl\;
//   iters=(TEXT_WINDOW_HEIGHT+1)*TEXT_WINDOW_WIDTH;
//   while( iters )
//     {
//     *bufptr=c;
//     iters--;
//     bufptr++;
//     }
//
// But the caveat is that all bytes MUST be contiguous or
// memory corruption will result.  You could optimize this
// even more by unrolling the loop 4 times.  ^_^
//
ptr=PrintStuff_Matrix;
cnt=PrintStuff_WinHeight*PrintStuff_WinWidth;
while( cnt )
  {
  *ptr=c;
  ptr++;
  cnt--;
  }  // while( cnt )

// add the trailing NULL to terminate this "string"!
*ptr=0;
}

// ......................................................................
// in:    left, top, right, bottom
// out:   -
// desc:  Sets the text clipping window.
// notes: It is, by default, whatever you initialize the text matrix
//        to be.  You can not specify a window outside of the text
//        matrix range.
// ......................................................................
void PrintClip( int l, int t, int r, int b )
{
int     i;

// make sure that l/r are in order
if( l>r )
  {
  i=l;
  l=r;
  r=i;
  }  // if( l>r )

// make sure that t/b are in order
if( t>b )
  {
  i=t;
  t=b;
  b=i;
  }  // if( t>b )

// make sure that l/t are 0 or greater
if( l<0 )
  l=0;

if( t<0 )
  t=0;

// make sure that r/b are within the current height and width!
if( r=PrintStuff_WinWidth )
  r=PrintStuff_WinWidth;

if( b=PrintStuff_WinHeight )
  b=PrintStuff_WinHeight;

// now copy the values to the real variables
PrintStuff_WinLeft   = l;
PrintStuff_WinTop    = t;
PrintStuff_WinRight  = r;
PrintStuff_WinBottom = b;
}

// ......................................................................
// in:    -
// out:   -
// desc:  Flushes output to the REAL print stream
// notes: -
// ......................................................................
void PrintFlush( void )
{
FntPrint(PrintStuff_Matrix);
FntFlush(-1);
}

// ......................................................................
// in:    texture page x*, texture page y*, blank the text
//        background? (1=yes), text window width, text window height,
//	  window X adjustment (pixels), window Y adjustment (pixels)
// out:   stream ID
// desc:  Initializes the print stuff.
// notes: right now, it doesn't do anything special---it's just a wrapper
//        for FntLoad().
//
// notes: *see FntLoad() in the Library Reference documentation.
//
// notes: The width*height can't be more than 1024!  This is a PSX
//        library software limitation.
// ......................................................................
int PrintInit( int tx, int ty, int bg_on, int w, int h, int ax, int ay )
{
FntLoad(tx,ty);

// print warning message if w*h too large
if( w*h > 1024 )
  {
  printf( "\nWARNING: PrintInit():\n" \
	"\tWidth and height larger than 1024!  Some clipping will occur.\n" \
	"\t(%d characters will be missing!)\n\n",(w*h)-1024 );
  }  // if( w*h > 1024 )

// copy the window dimensions to variables.
PrintStuff_WinWidth = w;
PrintStuff_WinHeight = h;

// note: since the fonts are 8x8 pixel blocks and the height and width
//       parameters are pixels, we multiply the specified text window
//       height/width by 8---written as a shift-left 3 bits because that's
//       a helluva lot faster.  And, if the compiler optimizes, the
//       following actually turns into a constant so no run-time
//       calculation is required!
PrintStuff_StreamID=FntOpen(TEXT_WINDOW_LEFT+ax,TEXT_WINDOW_TOP+ay,
        w<<3,h<<3,bg_on,(h*w)+2);

PrintClip(0,0,w,h);

PrintClear(0);

PrintStuff_Matrix[h*w]=0;

return(PrintStuff_StreamID);
}

// ......................................................................
// in:    column position (x), row position (y), null-terminated message
//        string
// out:   -
// desc:  Prints a string of text to the screen at the specified (X,Y)
// notes: All print strings are CLIPPED to the window
//        (0,0)-(width-1,height-1).  Remember that the width and height
//        are -1!!! You should have specified the width and height
//        parameters in the PrintInit() setup phase.
//
// notes: Only ASCII characters 32-126 are shown, with the exception of
//        a newline.  All characters outside of these are interpreted
//        as spaces.
//
// notes: You need to call a PrintFlush() when you want text to be shown!
//        Otherwise, it will all just sit in the local buffer... :P
//
// notes: This is really slow, but it works!
//
// notes: Be sure you've called PrintInit() before using PrintXY()!
//
// notes: the message string is just a character stream.  If you need
//        to format it, you should do something like:
//
//            char buf[80][25];
//
//            PrintXY( 142,42,0,sprintf(buf,"Score: %d",score) );
//
//        Use sprintf() to format your string.
// ......................................................................
void PrintXY( int x, int y, char *str )
{
char    c;
int     initial_x=x;

// is this string even in printable range?!
if( x>=PrintStuff_WinRight || y>=PrintStuff_WinBottom )
  { return; }

// we store the character into a local variable mainly because it's faster.
// No pointer dereferencing needed.
c = *str;

while( c != 0 && y<PrintStuff_WinBottom )
  {
  if( c == '\n' )
    {
    // NEWLINE?

    // remember that we saved the initial X position in a variable.
    // we'll use that as our reference point.
    x=initial_x;

    // down a line we go...
    y++;
    }  // if( c == '\n' )
  else
    {
    // NORMAL CHAR?

    // make sure it's printable
    if( c<32 || c>126 )
      { c=32; }

    // now print it if it's within the buffer
    // note: the the bottom window Y-checking is already done in
    //       the loop control.
    if( x>=PrintStuff_WinLeft && x<PrintStuff_WinRight &&
        y>=PrintStuff_WinTop )
      {
      // add it to the buffer!
      PrintStuff_Matrix[(y*PrintStuff_WinRight)+x]=c;
      }  // if( ... )

    // next character!
    x++;
    }  // else if( c == '\n' )

  // next character?
  str++;
  c=*str;
  }  // while( c != 0 && y<PrintStuff_WinBottom )
}

// [end]
