// program:     pad control routines
// mainfile:    padstuff.c
//
// file:        padstuff.c
// created:     23 Jan 1998
// version:     1.0.1
// author:      Elliott Lee
// company:     Protocol Software
// e-mail:      tenchi@shell.jps.net
// url:         http://www.jps.net/tenchi
//
// copyright:   (C) 1998 Elliott Lee
// copyright:   Portions (C) 1998 Sony Computer Entertainment Inc.
//
// description: Control Pad routines.  
//
//              This was derived from the combination of the PAD.H and
//              PAD.C files provided with the Yaroze.  These routines
//              behave closely---but not the same---to the provided ones.
//              Note the change in the pad key assignment constants!
//
// notes:       [25 Jan 1998: tenchi]
//              Added the PadPause() routine.
//              Added the diagonal directions.
//
// notes:       [16 Feb 1998: tenchi]
//              Added the PadPushed() and PadReleased routines.  Needed
//              to add a two-level button buffer to trap changes between
//              the current call to PadGet()/PadGet2() and the previous
//              one.  The problem stemmed from the fact that the main pad
//              buffer is overwritten any time between vertical retraces.
//              If we don't buffer the keys twice, we stand the chance
//              of reading in the same button presses in the same vertical
//              retrace period.

// ......................................................................
// HEADER FILES
// ......................................................................

#include "padstuff.h"

// ......................................................................
// FUNCTIONS
// ......................................................................

// ......................................................................
// in:    which pad?
// out:   -
// desc:  Copies a single pad's button data "backwards" into the
//        button press buffer and copies the current data into the
//	 top of the queue...
// notes: DON'T USE THIS.
//        DON'T USE THIS.
//        DON'T USE THIS.
//
//        This is for internal use only by PadGet() and PadGet2();
// ......................................................................
void PadBackcopy( int WhichPad )
{
int i;

for( i=0; i<4; i++ )
  {
  // copy the old values
  //
  // note: our buffers are ARRAYS.
  _PadBufOld[1][WhichPad][i] = _PadBufOld[0][WhichPad][i];

  // load in the new values
  //
  // note: the hardware buffer is a POINTER.
  _PadBufOld[0][WhichPad][i] = *(_PadBuf[WhichPad]+i);
  }  // for( i=0; i<4; i++ )
}

// ......................................................................
// in:    long pad status buffer, button flags (ORed together),
//        exact buttons? (1=yes,0=no)*
// out:   1=all buttons pressed 0=not all buttons pressed
// desc:  Checks to see if all the specified buttons are pressed.
// notes: Only use return data from PadGet().
//        This routine is slower than just ANDing the PadStatus
//        and the button flags.  BUT, this ensures that ALL specified
//        buttons have been pressed!
//
// notes: *if YES (1), then this function will return true only if
//        just the button flags specified are pressed.  This is
//        useful when you want the player to ONLY press START and
//        no other buttons.
//
// exmp:  // get the pad status for BOTH controllers.
//        PadStatus = PadGet();
//
//        // see if the player is going in the upper-right direction
//        if( PadButtons(PadStatus,PAD1UP|PAD1RIGHT) )
//          { handle the direction... }
//
//        // see if the player is going left and is holding the X
//        // button
//        if( PadButtons(PadStatus,PAD1LEFT|PAD1CROSS) )
//          { handle this event... }
//
//        // since we can handle both controllers at the same time,
//        // we can check to see if both players are pushing right
//        // at the same time!
//        if( PadButtons(PadStatus,PAD1RIGHT|PAD2RIGHT) )
//          { handle this event... }
// ......................................................................
int PadButtons( u_long PadStatus, u_long Flags, int exact )
{
if( exact )
  {
  // we'll see if any of the non-specified bits are set...
  if( (~Flags)&PadStatus )
    { return(0); }
  }  // if( exact )

if( (PadStatus&Flags) == Flags )
  { return(1); }
return(0);
}

// ......................................................................
// in:    NORMAL INT pad status buffer, button flags (ORed together),
//        exact buttons? (1=yes,0=no)*
// out:   1=all buttons pressed 0=not all buttons pressed
// desc:  Checks to see if all the specified buttons are pressed.
// notes: Only use return data from PadGet2().  
//        This routine is slower than just ANDing the PadStatus
//        and the button flags.  BUT, this ensures that ALL specified
//        buttons have been pressed!
//
// notes: *if YES (1), then this function will return true only if
//        just the button flags specified are pressed.  This is
//        useful when you want the player to ONLY press START and
//        no other buttons.
//
// notes: This routine is fundamentally the same as PadGet(), but this 
//        is tailored for 1 controller pad only.  The advantage here
//        is if you have to handle the events for 2 players in the same
//        program loop, you don't have to write specific defines for
//        each.  Check out this one:
//
// exmp:  for( pad=PAD1; pad<=PAD2; pad++ )
//          {
//          // get status for this pad ONLY
//          PadStat = GetPad2(pad);
//
//          // take care of the directions...
//          // notice that we use the PAD1 defines.  PAD1 defines can
//          // be used for examining one pad at a time.
//          if( PadButtons2(PadStat,PAD1LEFT) )
//            { left stuff... }
//          if( PadButtons2(PadStat,PAD1LEFT|PAD1UP) )
//            { up-left diagonal stuff... }
//          if( PadButtons2(PadStat,PAD1UP) )
//            { up stuff... }
//
//          if( PadButtons2(PadStat,PAD1CROSS|PAD1SQAURE) )
//            { multi-button press... }
//          }
// ......................................................................
int PadButtons2( u_int PadStatus, u_int Flags, int exact )
{
int j,i;

if( exact )
  {
  // we'll see if any of the non-specified bits are set...
  if( (~Flags)&PadStatus )
    { return(0); }
  }  // if( exact )

if( (PadStatus&Flags) == Flags )
  { return(1); }
return(0);
}

// ......................................................................
// in:    pointer to current buf, pointer to prev buf
// out:   -
// desc:  converts the current and "previous" buffer values into
//	 2 unsigned longs
// notes: -
// ......................................................................
void PadCurPrev( u_long *current, u_long *previous )
{
// form the 32-bit pad status buffer where bits 0..15 are pad1, 16-31 are
// pad2.
*current = (~(
	*(_PadBuf[PAD1]+3)     | *(_PadBuf[PAD1]+2)<<8 |
	*(_PadBuf[PAD2]+3)<<16 | *(_PadBuf[PAD2]+2)<<24
	)) & (0xffff);

*previous = (~(
	(u_long) _PadBufOld[1][PAD1][3] |
	((u_long) _PadBufOld[1][PAD1][2])<<8 |
	((u_long) _PadBufOld[1][PAD2][3])<<16 |
	((u_long) _PadBufOld[1][PAD2][2])<<24
	));
}

// ......................................................................
// in:    -
// out:   an unsigned long with both pad buffer data!
// desc:  "Reads" the pad information.
// notes: We're actually just reading the low-level buffer specifically
//        set aside for controller data.
//
// notes: Reading that pad buffer more than once before a vertical
//        sync interruption won't do you much good---the buffers are only
//        updated once per vertical sync.  Just call this function to
//        get the buffer status and use that variable until the next
//        vsync.
//
// exmp:  u_long padstatus;
//
//        PadInit();
//
//        // ... insert the rest of your init code here
//
//        while(1)
//          {
//          // grab the current pad stuff.
//          padstatus=&PadRead();
//
//          // handle pad functions
//          if( padstatus & PAD1LEFT )
//            {
//            // left direction code
//            }
//          if( padstatus & PAD1RIGHT )
//            {
//            // right direction code
//            }
//
//          // ... other stuff before vert sync
//
//          } // while(1)
// ......................................................................
u_long PadGet( void )
{
PadBackcopy(PAD1);
PadBackcopy(PAD2);

// apparently, the byte structure is in reverse order and the pad buffer
// pointers are off by 2 bytes.
return( (~(
        *(_PadBuf[PAD1]+3)     | *(_PadBuf[PAD1]+2)<<8 |
        *(_PadBuf[PAD2]+3)<<16 | *(_PadBuf[PAD2]+2)<<24
        )) & 0xffff);
}

// ......................................................................
// in:    which pad (PAD1 or PAD2)
// out:   an unsigned int with status for that pad
// desc:  Returns only single pad data
// notes: This is slower, but maybe easier to read.
// ......................................................................
u_int PadGet2( u_int WhichPad )
{
PadBackcopy(WhichPad);

return( (~(*(_PadBuf[WhichPad]+3) | *(_PadBuf[WhichPad]+2)<<8)) & 0xffff );
}

// ......................................................................
// in:    -
// out:   -
// desc:  Initializes the control pad buffers.
// notes: This MUST be called prior to the first pad read or you'll get
//        pure garbage.  Hm... remap the pad buffer pointers to the
//        sound reverb area for _real_ fun.
// ......................................................................
void PadInit( void )
{
GetPadBuf( &_PadBuf[PAD1],&_PadBuf[PAD2] );
}

// ......................................................................
// in:    controller flags ORed together*, exact buttons? (1=yes,0=no)**
// out:   last u_long pad status
// desc:  waits for ALL the specified controller buttons to be pressed
//        down
// notes: *this are the u_long defines for PAD1 and PAD2
//
// notes: **we MUST match just the indicated buttons to exit.
//
// exmp:  printf( "Press START to continue..." );
//        PadPause( PAD1START,1 );
//
//        printf( "Just kidding.  Press L1 and L2 to continue." );
//        PadPause( PAD1L1 | PAD1L2,0 );
// ......................................................................
u_long PadPause( u_long Flagz, int exact )
{
u_long PadStatus;
int    done=0;

while( !done )
  {
  // we'll wait for the vertical sync because it's pointless to do
  // the pad test beforehand...
  VSync(0);
  PadStatus=PadGet();
  if( PadButtons(PadStatus,Flagz,exact) )
    done=1;
  }  // while( !done )

return( PadStatus );
}

// ......................................................................
// in:    which buttons to test?
// out:   -
// desc:  checks to see if the pad buttons have just been pushed between
//        the current call to PadGet() and the previous one.
// notes: This doesn't yet work with PadGet2!
// ......................................................................
int PadPushed( u_long Flags )
{
u_long current,previous;

// form the current/previous buffers.
PadCurPrev(&current,&previous);

if( (current&Flags)!=(previous&Flags) && (current&Flags)==Flags)
  return(1);

return(0);
}

// ......................................................................
// in:    which buttons to test?
// out:   -
// desc:  checks to see if the pad buttons have just been released between
//        the current call to PadGet() and the previous one.
// notes: This doesn't yet work with PadGet2!
// ......................................................................
int PadReleased( u_long Flags )
{
u_long current,previous;

// form the current/previous buffers.
PadCurPrev(&current,&previous);

if( (current&Flags)!=(previous&Flags) && (current&Flags)==0)
  return(1);

return(0);
}

// [end]
