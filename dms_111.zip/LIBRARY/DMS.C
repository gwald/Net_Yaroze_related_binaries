// program:	DMS Library
// mainfile:	dms.c
//
// file:	dms.c
// version:	1.1.0
// created:	7 Apr 1998
// updated:	7 May 1998
// author:	Elliott Lee
// company:	Protocol Software
// e-mail:      tenchi@shell.jps.net
// url:         http://www.jps.net/tenchi
//
// copyright:	(C) 1998 Elliott Lee
// copyright:	Portions (C) 1998 Sony Computer Entertainment Inc.
//
// description:	Routines to load and manage Digital Music Sequence (DMS)
//		files created by my utilities.
//
// notes:	OVERVIEW Q. & A.
//		================
//		Q. What is a DMS file?
//		A. Read the notes section just below.
//
//		Q. How do I create a DMS file?
//		A. You must format a MOD or S3M file into DMS format
//		   using the S2S utility.  Contact me or visit my Web
//		   page to get it.
//
//		Q. How do I play back a DMS file?
//		A. Just follow these steps:
//
//			1) load the DMS file into the Yaroze RAM
//			   (preferably in your batch file).  Also
//			   remember to load the VAB header and
//			   data somewhere into RAM.  You can have
//			   more than one set of DMS data per VAB!
//			   (Use that to save memory space!)
//			2) include in your Yaroze program the DMS
//			   library (DMS.C and DMS.H).
//			3) Your program program should have a variable
//			   of type "DMS".  You will use this as a
//			   handle!
//			4) Initialize the DMS variable by calling
//			   DMSInit() with the proper arguments.  Make
//			   absolutely SURE that DMSInit() returns the
//			   value DMS_OK or else your playback will not
//			   be pretty.
//			5) To play the song, just call DMSPoll() every
//			   video frame.  To stop playback, don't call
//			   DMSPoll()---too simple, right?
//
//		   For more information, you should see the DMSPoll()
//		   function header!
//
//		Q. What if I have problems with using this library?
//		A. I try to do quality work, but at 4:00AM I have been
//		   known to make typos.  :)  Just send me a bug report
//		   and I'll try to reproduce and patch up the problem.
//		   Don't just say "uh... it failed".  Tell me everything
//		   you know about your variables, all error messages,
//		   probable causes, etc.  The more info the better.
//		   maybe even a chunk of your code would help.
//
//		Q. I did everything right, but I'm still not getting
//		   ANY sound!
//		A. Did you set the global volumes for playback?  See
//		   Yaroze library functions SndVolume(), SsSetMVol().
//
//		Q. My S3M is all out of tune!  ARGH.
//		A. Try resampling it in S2S with the "-r" option.  This
//		   corrects most problems.
//
//		Q. My S3M is really big.  Can I use S2S to squeeze down
//		   the module size?
//		A. Yup.  Just pick a Hz number that's lower than most of
//		   the instruments.  The quality degradation is noticeable
//		   but bearable.  :)
//
// notes:	WHAT IS DMS?
//		============
//		DMS (Digital Music Sequence) is one way to allow the
//		Yaroze to play back MOD-type music, specifically S3M-
//		formatted music.  DMS has two basic parts to it: a
//		sound bank and sequence data.
//
//		The sound bank is a series of samples extracted from the
//		S3M file and converted into a Yaroze VAB.  Samples will
//		be converted to 16-bits, loops can be applied over the
//		ENTIRE sample, and reverb will affect the samples (put
//		the string "[r]" in the instrument name to force no
//		reverb).  You must use the utility S2S (also by me) to
//		properly extract the sounds.
//
//		The sequence data is also converted in S2S from the
//		pattern-based format to a time-event format.  Playback
//		is performed with this DMS library you are looking at
//		now.  All you need to do is:  1) initialize the DMS
//		structure, and 2) include the DMS polling routine in
//		every screen refresh.  DMS uses the vertical retrace
//		(60 fps for NTSC, 50 fps for PAL) to build the timing
//		base.  Thus, if gameplay slows down, so will your music.
//		Round-off errors will also cause some variations in
//		playback.
//
//		Each time the polling routine is called, a frame counter
//		is decremented.  When it reaches a certain point, the
//		next row of sequence data is processed and the frame
//		counter is reset.
//
//		The DMS format was contrived by me, Elliott Lee, in
//		late March 1998 after getting fed up with MIDI.
//
//		WHY NOT MIDI?
//		=============
//		MIDI would of course be the obvious choice to use because
//		it almost completely off-loads processing from the
//		programmer (DMS must do polling every frame), however
//		there are various problems with it and a lack of control
//		associated with it.  DMS is highly flexible, can play
//		back any number of DMS sequences per frame, is expandable
//		upon request, and is a smaller implementation.
//
//		HOW TO INTERACT WITH DMS
//		========================
//		Use only the API provided.  Sure, you can edit the structure
//		directly, but I do not guarantee that it will work in the
//		future.  Upgrades to the DMS system may change the data
//		structures, and your direct messing with them may cause
//		memory corruption.  Requests for more functionality will
//		be honored provided I have enough time to implement them.
//
//		TIMING ISSUES
//		=============
//		Ideally, a high-resolution timer is needed to provide
//		accurate, reliable playback.  Since none really exists,
//		I am using the vertical retrace period to calculate the
//		number of frames needed per row.  This number is very
//		prone to round-off errors.  The basic formula is:
//
//			V = (A*R*5)/(T*2)
//
//		Where:
//
//			V = # of video frames for this row
//			A = S3M speed
//			R = Refresh rate (NTSC=60, PAL=50)
//			T = S3M tempo
//
//		Testing proves that this formula will yield errors as high
//		as about 6 BPM for both NTSC and PAL.  If you are going to
//		be forcing your Yaroze to perform different refresh rates
//		(e.g. 30 fps), the formula will still work and you will still
//		receive a fairly large round-off error.  In general, the
//		round-off isn't so bad as the S3M plays back rather well.
//
//		S3M COMMANDS
//		============
//		There are but a handful of supported commands because of the
//		limitations of the Yaroze library.  Any command not understood
//		will be ignored.  The current list of known commands is:
//
//			Axx	Speed.  Really is the number of "frames" per
//				row.  The length of a "frame" is dependent
//				on the current tempo.
//			Bxx	Break to order xx.
//			Cxx	Break pattern and jump to row xx in
//				next order.
//				xx=0..3f.
//			Dx0	Volume slide up.
//				x=1..f.
//			Dxf	Fine volume slide up.
//				x=1..f.
//			D0x	Volume slide down.
//				x=1..f.
//			Dfx	Fine volume slide down.
//				x=1..f.
//			S8x	Set panning (S3M style). x=0..f, 0=far left,
//			        f=far right.
//			Txx	Set tempo to xx BPM.
//			Vxx	Set global volume to xx.  xx=0..64,
//			        64=loudest.
//			Xxx	Set panning (IT style).
//				xx=00..ff, 0=far left, ff=far right.
//				Don't use the S8x panning command!
//
//		KNOWN BUGS
//		==========
//		- Songs play back faster than normal.
//		    This is due to integer round-off using a low-resolution
//		    timer: the vertical retrace sync.  If anyone has ideas on
//		    how to get finer resolution, write me.
//
//		- Volumes are too quiet.
//		    The Yaroze volumes are rather odd in that the lower volumes
//		    are much lower than they ought to be.  You can attempt to
//		    compensate for this in the conversion of your S3M using the
//		    S2S utility's "-v" option.
//
//		- Adjusting global volume (Vxx command) doesn't change the
//		  volumes of instruments already playing.
//		    I know.  It only affects instruments that are keyed-on
//		    after this command is read.  I just haven't put in the
//		    code to adjust this yet.
//
//		FEATURES MISSING
//		================
//		- Pitch slides, portamento, and vibrato.
//		  None of these work yet.  Until I can confirm why the code
//		  will not work, we'll just have to leave them as to-do's.
//		  The code for pitch slides is actually there, but I've
//		  commented it out.  You still can make good music without
//		  them.  ^_^
//
//		SUPPORT FOR DMS
//		===============
//		No dedicated support currently exists.  You use this library
//		at your own risk and accept all consequences from using it
//		directly or indirectly.  I will certainly try to assist
//		any interested party in further developing DMS, but I can't
//		guarantee my availability.  I also do not guarantee that
//		any DMS specification is 100% free of errors.

// ......................................................................
// GENERAL INCLUDES
// ......................................................................
#include "dms.h"

// ......................................................................
// GLOBALS
// ......................................................................

// ......................................................................
// in:		pointer to DMS structure
// out:		.
// desc:	closes this DMS
// note:	you should always call DMSDeInit() to at least free up the
//		VAB!
// ......................................................................
void DMSDeInit( DMS *dms )
{
SsUtAllKeyOff(0);
if( dms->VabID >=0 )
  SsVabClose(dms->VabID);
}

// ......................................................................
// in:		DMS handle, event number (0 = pat0 row0),
//		pointer to DMS_EVENT structure
// out:		1 on success
// desc:	retrieves row data from DMS sequence
// note:	each DMS record must be 8 bytes wide!  If you change
//		the DMS file structure, consider this!
//
// note:	This is terrible.  I tried using a pointer to the memory
//		area but with no avail.  As a result, I must copy the
//		data byte-by-byte!
// ......................................................................
int DMSGetEvent( DMS *dms, int eventno, DMS_EVENT *eventstruc )
{
char	*addr,*evaddr;
int	i;

// make sure that the event number is within range!
if( eventno<0 || eventno>=(dms->Events) )
  return( DMS_EVENT_OUT_OF_RANGE );

addr = (char *)((dms->AddrDMSSeq)+(eventno<<3));
evaddr = (char *)eventstruc;

for( i=0; i<8; i++ )
  evaddr[i] = addr[i];

// pull values in bounds?
if( eventstruc->Volume > 127 )
  eventstruc->Volume = 127;

return(0);
}

// ......................................................................
// in:		pointer to DMS structure
// out:		DMS master volume
// desc:	Gets the master volume mixing for this DMS
// note:	-
// ......................................................................
int DMSGetMasterVol( DMS *dms )
{
return(dms->MasterVol);
}

// ......................................................................
// in:		pointer to DMS structure,
//		options,
//		number of video frames in 1 second,
//		address of VH, address of VB, address of DMS
// out:		success | error code
// desc:	sets up DMS structure!
// note:	don't forget to call DMSDeInit() when you're quitting!
// note:	each DMS entry must be 8 bytes wide!
// ......................................................................
int DMSInit( 
	DMS *dms,
	unsigned int options,
	unsigned int fps,
	unsigned char *addr_vh,
	unsigned char *addr_vb,
	unsigned char *addr_dms
	)
{
unsigned char	*c;
DMS_HEADER	*hdr;
int		i,k=0;
int		*pos;

// Is this a DMS file?
if( !DMSIsDMS(addr_dms) )
  return( DMS_NOT_DMS );

// Set the header structure over the data
hdr=(DMS_HEADER *)addr_dms;

// Store the addresses!
dms->AddrDMS = addr_dms;
dms->AddrVB  = addr_vb;
dms->AddrVH  = addr_vh;

// Name, please.  Only 31 chars.
strncpy(dms->SongName,hdr->SongName,31);
dms->SongName[31]=0;

// Version control
dms->VersionHi = hdr->VersionHi;
dms->VersionLo = hdr->VersionLo;
if( dms->VersionHi>DMS_MAX_VERSION )
  return( DMS_WRONG_VERSION );

// Other stuff
dms->Channels		= hdr->Channels;
dms->CurSpeed		= hdr->Speed;
dms->CurTempo		= hdr->Tempo;
dms->Flags		= hdr->Flags;
dms->GlobalVol		= 64;
dms->Instruments	= hdr->Instruments;
dms->NoteCor		= 0;
dms->Orders		= hdr->Orders;
dms->Patterns		= hdr->Patterns;
dms->Rows		= hdr->Rows;
dms->VideoRefresh	= fps;
for( i=0; i<6; i++ )
  { k^=(unsigned)hdr->Padding[i]; }
DMSSetMasterVol(dms,DMS_VOL_RESOLUTION);

// Check some of the above
if( dms->Channels>DMS_MAX_CHANNELS )
  return( DMS_TOO_MANY_CHANS );
if( (dms->Orders)<1 || (dms->Instruments)<1 ||
    (dms->Patterns)<1 )
  {
  printf( "ERROR: NumOrders=%d NumInstruments=%d NumPatterns=%d\n",
	dms->Orders,dms->Instruments,dms->Patterns );
  return( DMS_ZERO_STUFF );
  }  // if( (dms->Orders)<1 || (dms->Instruments)<1 || ... )

// Find the orders and pats!
dms->AddrDMSOrder	= addr_dms + (hdr->Len) + 8;
k+=5;k			= k>>4;
pos 			= (int *)(addr_dms + (hdr->Len) + k);
dms->AddrDMSSeq		= addr_dms + (hdr->Len) + *pos + (k<<1);

// Find the number of events in this DMS so we don't overflow the memory!
// NOTE: This is really ridiculous.  I tried using an integer pointer but
//       the Yaroze kept crashing.  I DON'T understand why it is so, but
//       I've found that pointers really suck on the Yaroze.  The compiler
//       must be doing something wrong because I could just be able to say:
//
//		pos = (int *)(dms->AddrDMSSeq - k);
//		dms->Events = (*pos - k)/k;
//
//       So, instead, I suck up every byte and put it back into Intel
//       byte order.
//
c		= (char *)(dms->AddrDMSSeq - k);
dms->Events	= ((unsigned int)c[0]) +
		  (((unsigned int)c[1])<<8) +
		  (((unsigned int)c[2])<<16) +
		  (((unsigned int)c[3])<<24);
dms->Events	= (dms->Events - k)/(k<<1);

// Reset the internal state variables.
for( i=0; i<DMS_MAX_CHANNELS; i++ )
  {
  dms->Chan2Voice[i]	= -1;
  dms->ChanInstr[i]	= -1;
  dms->ChanLCmd[i]	= 255;
  dms->ChanNote[i]	= -1;
  dms->ChanPan[i]	= (DMS_PAN_RESOLUTION<<1)/k;
  dms->ChanVol[i]	= 0; 
  dms->ChanSldVol[i]	= 0;
  dms->ChanSldVolOld[i]	= 0;
  }  // for( i=0; i<DMS_MAX_CHANNELS; i++ )

// Set the tables up (16 positions!)
//
// You may ask how I came up with this number.  I found that for an
// Impulse Tracker instrument, to go from Volume 0 to Volume 60 took exactly
// 1.5 seconds.  Based on the video refresh rate, you can estimate how
// much volume sliding to do per video frame.  The fine volume slide
// ended up being 1/5 of the normal volume rate.
//
// The number is actually a 24.8 fixed-point decimal, the last 8 bits being
// the decimal portion.  (That's why the dividend is so large.)
for( i=0; i<16; i++ )
  {
  dms->VolSlideTable[i]=(10240*i)/(dms->VideoRefresh);
  dms->VolSlideTableF[i]=(2048*i)/(dms->VideoRefresh);
  }  // for( i=0; i<16; i++ )

// Load that VAB!
//
// note: the "-1" auto-selects our VAB ID from the
//       available pool
dms->VabID = SsVabTransfer(dms->AddrVH,dms->AddrVB,-1,1);
if( dms->VabID<0 )
  return(DMS_VAB_ERROR);

// Final variable setup.  Reset the playback state!
DMSSongReset(dms);

return(DMS_OK);
}

// ......................................................................
// in:		address of DMS
// out:		1=yes | 0=no
// desc:	test to see if this is a DMS file that we can use
// note:	.
// ......................................................................
int DMSIsDMS( unsigned char *addr )
{
if( addr[0]=='D' && addr[1]=='M' && addr[2]=='S' && addr[3]=='H' )
  return(1);
else
  return(0);
}

// ......................................................................
// in:		pointer to DMS structure, which channel?
// out:		error message
// desc:	keys off all playing notes for this DMS
// note:	remember that the note must be bit-shifted 16!
// ......................................................................
int DMSNoteKeyOff( DMS *dms, int c )
{
// channel not in range?
if( c<0 || c>=DMS_MAX_CHANNELS )
  return( DMS_CHAN_OUT_OF_RANGE );

// not playing?
if( dms->Chan2Voice[c]<0 )
  return( DMS_OK );

// off!
SsUtKeyOff(
	dms->Chan2Voice[c],
	dms->VabID,
	dms->ChanInstr[c],
	0,				// Tone is always 0!
	(dms->ChanNote[c])>>16
	);

dms->Chan2Voice[c]=-1;

return(DMS_OK);
}

// ......................................................................
// in:		pointer to DMS structure
// out:		error message
// desc:	keys off all playing notes for this DMS
// note:	.
// ......................................................................
int DMSNoteKeyOffAll( DMS *dms )
{
int	c;

for( c=0; c<DMS_MAX_CHANNELS; c++ )
  DMSNoteKeyOff( dms,c );

return(DMS_OK);
}

// ......................................................................
// in:		current speed, current tempo, number of video frames per
//		second
// out:		number of video frames for this row
// desc:	calculates the number of video frames needed for this
//		row
// note:	The formula, as stated at the top of the file is really:
//
//			V = (A*R*5) / (T*2);
//
//		But, in order to try to eliminate some round-off error,
//		I multipled the constants by 128.
//
// ......................................................................
int DMSNumberRowFrames( int speed, int tempo, int fps )
{
if( tempo<1 )
  return(99999);
return( (speed*fps*640)/(tempo<<8) );
}

// ......................................................................
// in:		pointer to DMS structure, order number
// out:		error message
// desc:	moves the order pointer to the desired order and
//		sets the playback pointer to the top of that pattern
// note:	.
// ......................................................................
int DMSOrderJump( DMS *dms, int ordnum )
{
int	result = DMS_OK;

dms->CurRow	= dms->Rows;
dms->EventPtr	= 0;
dms->EventTime	= 0;
dms->FramesLeft	= -1;
dms->GlobalVol	= 64;

dms->CurOrder	= ordnum;
if( dms->CurOrder<0 )
  {
  result = DMS_ORDER_OUT_OF_RANGE;
  dms->CurOrder=0;  
  }  // if( dms->CurOrder<0 )
if( dms->CurOrder>=dms->Orders )
  {
  result = DMS_ORDER_OUT_OF_RANGE;
  dms->CurOrder=0;  
  }  // if( dms->CurOrder<0 )
dms->CurOrder--;

DMSNoteKeyOffAll(dms);

return(result);
}

// ......................................................................
// in:		pointer to DMS structure
// out:		status
// desc:	polls the DMS routines once
// note:	this should be called EVERY FRAME!  This is the workhorse
//		of the DMS libraries.  Please see below for functionality.
//
// note:	The values in this routine are very specific to the
//		current Yaroze libraries.  This is because we get an
//		increase in the speed of the routine if we have constant
//		values for the math and the bounds of the values.
//
// note:	The formula for determining the left/right outputs
//		for each note played mixes the Channel Voice, Global
//		Volume, Master Volume, and then compensates for the
//		current Pan Position.  You'll note that the numbers get
//		quite large but then are bit-shifted back into the
//		0..128 range.
//
// note:	In order to achieve a fine resolution of pitch, each
//		pitch is set so that the lower 16 bits describe the
//		tuning of the note while the upper 16 bits describe the
//		pitch of the note.
// ......................................................................
int DMSPoll( DMS *dms )
{
int		c;
int		changepan;
int		desiredtime;
DMS_EVENT	e;
int		evptr;
int		pitchold;
int		ptrlo,ptrmid,ptrhi;
int		result;
int		vol,voll,volr;
int		volglomas;

// ----------------------------------------
//    SECTION 1: Frame-by-frame handling
// ----------------------------------------
//    This area handles all calculations that go on for every single
//    call to this polling routine.  This will depend on the current
//    (last) command that was read.

volglomas = dms->MasterVol * dms->GlobalVol;
for( c=0; c<DMS_MAX_CHANNELS; c++ )
  {
  switch( dms->ChanLCmd[c] + 'A' - 1 )
    {
    case 'D' : // Handle volume sliding
      // is this channel actively playing something and has a sliding value that
      // is nonzero?
      if( dms->Chan2Voice[c]>=0 && dms->ChanSldVol[c]!=0 )
        {
        // Begin by modifying the channel volume.
        dms->ChanVol[c] += dms->ChanSldVol[c];

        // make sure the value is in-bounds
        if( dms->ChanVol[c]<0 ) 
          dms->ChanVol[c]=0;
        if( dms->ChanVol[c]>16384 )
          dms->ChanVol[c]=16384;

        // calculate the left/right volumes
        volr = dms->ChanPan[c];
        voll = 256-volr;
        vol  = (volglomas * dms->ChanVol[c]) >> 14;
        volr = (volr * vol) >> 14;
        voll = (voll * vol) >> 14;

        // tell the SPU the good news...
        SsUtSetVVol( dms->Chan2Voice[c],voll,volr );
        }  // if( Chan2Voice[c]>=0 && ChanVol[c]>0 && ChanSldVol[c]!=0 )
      break;
//
//  PITCH SLIDES DISABLED
//  =====================
//  This is the code which should control the pitch sliding.  Everything appears to
//  look fine, but I can only pitch slide the fine tuning of a note, but not change the
//  note's semitone value.  It's probably something obvious I'm missing, but I could not
//  track down the problem.  Uncomment and play with this.  If you come up with a bug
//  fix, please let me know by all means.  Thanks!
//
//  p.s. There's one more uncommented code section below.
//
//    case 'E' : case 'F' : // Handle pitch sliding
//      // is this channel actively playing something and has a sliding value that
//      // is nonzero?
//      if( dms->Chan2Voice[c]>=0 && dms->ChanSldPitch[c]!=0 )
//        {
//	// Save the old pitch
//	pitchold = dms->ChanNote[c];
//
//        // Modify the channel pitch.
//        dms->ChanNote[c] += dms->ChanSldPitch[c];
//
//	printf( "",dms->Chan2Voice[c],dms->ChanInstr[c],pitchold>>16,(dms->ChanNote[c])>>16 );
//
//        // Update the SPU pitch!
//        printf( "%d,%d,%d:%d,%d=%d ",
//		dms->Chan2Voice[c],dms->VabID,dms->ChanInstr[c],
//		pitchold>>16,
//		(dms->ChanNote[c])>>16,
//	SsUtChangePitch( dms->Chan2Voice[c],dms->VabID,dms->ChanInstr[c],
//		pitchold>>16,0,
//		(dms->ChanNote[c])>>16,0
//		)
//		);
//
//        }  // if( dms->Chan2Voice[c]>=0 && dms->ChanSldPitch[c]!=0 )
//      break;
//
    }  // switch( dms->ChanLCmd[c] + 'A' - 1 )
  }  // for( c=0; c<DMS_MAX_CHANNELS; c++ )

// We'll reduce the frame count here.  When it reaches 0 (or lower) then
// we know that it's time to jump to the next row!  Otherwise, just quit.
dms->FramesLeft--;
if( dms->FramesLeft>0 )
  return(DMS_OK);

// -----------------------------------
//    SECTION 2: New row processing
// -----------------------------------
//    This area handles the advancement of the event pointer and the
//    triggering of new events.

// ROW CLEAN-UP
// ============
// Clear the last command
for( c=0; c<DMS_MAX_CHANNELS; c++ )
  { dms->ChanLCmd[c]=0; }

// ROW HANDLING
// ============
// Okay, jump to the next row in sequence!
dms->CurRow++;

// Is this row in bounds?  If the row is <0, then set it to 0.  If more
// than the number of rows in a pattern, then increase the Order!
if( dms->CurRow < 0 )
  dms->CurRow=0;
if( dms->CurRow >= dms->Rows || dms->ForcePatBreak )
  {
  // first reset the row counter to 0 (the beginning of the row!) unless
  // a pattern break was forced...
  if( dms->ForcePatBreak )
    {
    dms->ForcePatBreak=0;
    dms->CurRow--;

    // if the row isn't in range, then reset to zero!
    if( dms->CurRow >= dms->Rows )
      dms->CurRow=0;
    }  // if( dms->ForcePatBreak )
  else
    dms->CurRow=0;

  // Increase the order, skipping any "++" markers (254).
  dms->CurOrder++;
  while( dms->AddrDMSOrder[dms->CurOrder]==254 &&
         dms->CurOrder<dms->Orders )
    { dms->CurOrder++; }

  // Check to see if we ran out of orders or hit the end-of-song mark.
  // If so, then reset to 0 (the first order).
  if( dms->CurOrder >= dms->Orders || dms->AddrDMSOrder[dms->CurOrder]==255)
    dms->CurOrder = 0;

  // Now here's the tricky part.  We have to seek the event pointer down
  // to the correct time in the huge mess!
  //
  // NOTE: For testing purposes, I'm going to do a binary search.  Every
  //       event should be in ascending order---if it isn't then we have
  //       a BIG problem.  You can also convert the division into bit
  //       shifting to get a little performance boost.

  // set the bounds
  ptrlo = 0;
  ptrhi = dms->Events - 1;

  // We'll also need the time we're looking for.
  desiredtime = dms->AddrDMSOrder[dms->CurOrder] * dms->Rows;

  // Now find that time!
  ptrmid = (ptrlo+ptrhi)/2;
  result=DMSGetEvent( dms,ptrmid,&e );

  while( 
	(result==DMS_OK) && 
	e.Time != desiredtime &&
	(ptrhi-ptrlo)>0
	)
    {
    // now figure out which way to go!
    if( e.Time>desiredtime )
      {
      // we're too high... reduce top bounds down
      ptrhi=ptrmid-1;
      }  // if( e.Time>desiredtime )
    else
      {
      // too low.  go up!
      ptrlo=ptrmid+1;
      }  // if( e.Time>desiredtime )

    // get the new event time!
    ptrmid = (ptrlo+ptrhi)/2;
    result=DMSGetEvent( dms,ptrmid,&e );
    }  // while( result==DMS_OK )

  // okay, ptrmid should be pointing at a record where the time is 
  // greater than or equal to the actual event we're looking for.
  // So, now we just shimmy down...
  while( ptrmid>=0 && e.Time>=desiredtime && result==DMS_OK)
    {
    ptrmid--;
    result=DMSGetEvent( dms,ptrmid,&e );
    }  // while( ptrmid>0 && e.Time>=desiredtime && result==DMS_OK)

  // OK.  We missed the row by 1!  Go back up!
  ptrmid++;

  // make sure that ptrmid is still in range
  if( ptrmid<0 )
    ptrmid=0;

  // Eureka! Save our position!
  dms->EventPtr = ptrmid;
  }  // if( dms->CurRow >= dms->Rows )

// Now that the rows and the orders are set, we'll actually calculate the
// timestamp that we need to seek to.
dms->EventTime = ((int)dms->AddrDMSOrder[dms->CurOrder] * dms->Rows) + 
		 dms->CurRow;

// Now play all rows between the current EventPtr position and the EventTime.
// There may be any number of rows played back!  We'll copy the time and
// current pointer values to local variables to save dereferencing time.
evptr		= dms->EventPtr;
desiredtime	= dms->EventTime;
result		= DMSGetEvent( dms,evptr,&e );
volglomas	= dms->MasterVol * dms->GlobalVol;

while( result==DMS_OK && e.Time<=desiredtime && evptr<dms->Events)
  {
  // interpret the data structure!

  // note, the Channel member is non-negative.
  if( (int)e.Channel<DMS_MAX_CHANNELS )
    {
    // cool!  we got an event!

    // reset a flag
    changepan=0;

    // handle effects first!
    // Remember to save the command to the command buffer.
    dms->ChanLCmd[e.Channel]=e.Command;
    switch( e.Command + 'A' - 1 )
      {
      case 'A' :	// set speed to N
        if( e.Info > 0 )
          dms->CurSpeed = e.Info;
        break;
      case 'B' :  // break to order N
        if( e.Info < dms->Orders )
          {
          dms->ForcePatBreak=1;
          dms->CurRow = 0;
          dms->CurOrder = ((int)e.Info) - 1;
          }  // if( e.Info < dms->Orders )
        break;
      case 'C' :  // break to row N in next pattern
        dms->ForcePatBreak=1;
        dms->CurRow = e.Info;
        break;
      case 'D' :  // volume sliding
	// use the last value?
        if( e.Info==0 )
          dms->ChanSldVol[e.Channel]=dms->ChanSldVolOld[e.Channel];
        else
          {
	  // no, set w/ new value!

          if( (e.Info&(0xf0))==0 )				// down
            dms->ChanSldVol[e.Channel]=0-dms->VolSlideTable[e.Info&(0x0f)];
          else if( (e.Info&(0x0f))==0 )				// up
            dms->ChanSldVol[e.Channel]=dms->VolSlideTable[(e.Info&(0xf0))>>4];
          else if( (e.Info&(0xf0))==(0xf0) )			// fine down!
            dms->ChanSldVol[e.Channel]=0-dms->VolSlideTableF[e.Info&(0x0f)];
          else if((e.Info&(0x0f))==(0x0f) )			// fine up!
            dms->ChanSldVol[e.Channel]=dms->VolSlideTableF[(e.Info&(0xf0))>>4];

  	  // save current slide value!
          dms->ChanSldVolOld[e.Channel]=dms->ChanSldVol[e.Channel];
          }  // if( e.Info==0 )
        break;
//
//  PITCH SLIDE COMMAND INTERPRETATION CODE
//  =======================================
//  You also need to uncomment this part, too.
//
//      case 'E' :  // pitch slide down
//	// use the last value?
//        if( e.Info==0 )
//          dms->ChanSldPitch[e.Channel]=dms->ChanSldPitchOld[e.Channel];
//        else
//          {
//	  // no, set w/ new value!
//          if( (e.Info&(0xf0))==(0xf0) )		// FFx, fine slide
//	    dms->ChanSldPitch[e.Channel] = 0-(DMS_PITCH_SLIDE_FINE * (e.Info&(0xf)));
//	  else if( (e.Info&(0xf0))==(0xf0) )	// FEx, extra fine slide
//	    dms->ChanSldPitch[e.Channel] = 0-(DMS_PITCH_SLIDE_XFINE * (e.Info&(0xf)));
//	  else
//            dms->ChanSldPitch[e.Channel] = 0-(DMS_PITCH_SLIDE * e.Info);
//
//  	  // save current slide value!
//          dms->ChanSldPitchOld[e.Channel]=dms->ChanSldPitch[e.Channel];
//          }  // if( e.Info==0 )
//        break;
//      case 'F' :  // pitch slide up
//	// use the last value?
//        if( e.Info==0 )
//          {
//          dms->ChanSldPitch[e.Channel]=dms->ChanSldPitchOld[e.Channel];
//          printf( "." );
//          }
//        else
//          {
//	  // no, set w/ new value!
//          if( (e.Info&(0xf0))==(0xf0) )		// FFx, fine slide
//	    dms->ChanSldPitch[e.Channel] = DMS_PITCH_SLIDE_FINE * (e.Info&(0xf));
//	  else if( (e.Info&(0xf0))==(0xf0) )	// FEx, extra fine slide
//	    dms->ChanSldPitch[e.Channel] = DMS_PITCH_SLIDE_XFINE * (e.Info&(0xf));
//	  else
//            dms->ChanSldPitch[e.Channel] = DMS_PITCH_SLIDE * e.Info;
//
//  	  // save current slide value!
//          dms->ChanSldPitchOld[e.Channel]=dms->ChanSldPitch[e.Channel];
//
//          printf( "," );
//          }  // if( e.Info==0 )
//        break;
//
      case 'S' :  // extra functions
        if( e.Info >= (0x80) && e.Info <= (0x8f) )
          {
          // set pan position (0=left, 7/8=about center, F=almost right)
    	  // result should be 0..255
          dms->ChanPan[e.Channel] = (e.Info&(0xf))*17;
	  changepan=1;
          }  // if( e.Info >= (0x80) && e.Info <= (0x8f) )
        break;
      case 'T' :  // set tempo
        dms->CurTempo = e.Info;
        break;
      case 'V' :  // DMS global volume (not the master!)
        dms->GlobalVol = e.Info;
        break;
      case 'X' :  // set channel pan position to N
	// note: The info must be multiplied by 2.  Weird.
        dms->ChanPan[e.Channel] = e.Info*2;
	changepan=1;
        break;
      }  // switch( e.Command + 'A' - 1 )

    // change the pan position?
    if( changepan && dms->Chan2Voice[e.Channel]>=0 )
      {
      // calculate the left/right volumes
      vol  = (volglomas * dms->ChanVol[e.Channel]) >> 15;
      volr = dms->ChanPan[e.Channel];
      voll = 255-volr;
      volr = (volr * vol) >> 14;
      voll = (voll * vol) >> 14;

      // tell the SPU the good news...
      SsUtSetVVol( dms->Chan2Voice[e.Channel],voll,volr );
      }  // if( changepan && dms->Chan2Voice[e.Channel]>=0 )

    // are we starting a new note?
    if( e.Note<254 && e.Instrument>0 )
      {
      // is there an instrument already playing on this channel?
      if( dms->Chan2Voice[e.Channel] >= 0 )
	DMSNoteKeyOff( dms,e.Channel );

      // save instrument state
      dms->ChanInstr[e.Channel] = e.Instrument-1;
      dms->ChanNote[e.Channel] = (e.Note+dms->NoteCor)<<16;
      dms->ChanVol[e.Channel] = ((int)e.Volume)<<8;
      if( dms->ChanVol[e.Channel]>16384 )
        dms->ChanVol[e.Channel]=16384;

      // now the final volume is tricky because we have to mix the
      // Global, Master, and Channel volumes together!  First begin by
      // calculating the volume split over the left and right channels.
      // The channel pan is between 0..255.
      volr = dms->ChanPan[e.Channel];
      voll = 256-volr;

      // Now, amplify the left and right volumes to the current volume!
      vol = (volglomas * dms->ChanVol[e.Channel]) >> 14;
      voll = (voll * vol) >> 14;
      volr = (volr * vol) >> 14;

      // Note: The way the volumes work, a center pan is only half-strength
      //       of the instrument.  Ridiculous, but easy to calculate!

      // okay now play the new one!
      dms->Chan2Voice[e.Channel] = SsUtKeyOn(
		dms->VabID,
		dms->ChanInstr[e.Channel],
		0,				// Tone is always 0!
		(dms->ChanNote[e.Channel])>>16,
		((dms->ChanNote[e.Channel])>>10)&(0x3f),
		voll,
		volr
		);

      // did it actually play?  maybe it ran out of channels...
      if( dms->Chan2Voice[e.Channel]>254 )
        dms->Chan2Voice[e.Channel] = -1;
      }  // if( e.Note<254 && e.Instrument<254 )
    else if( e.Note==254 ) 			// are we keying-off?
      DMSNoteKeyOff( dms,e.Channel );
    else if( e.Volume<=64 && dms->Chan2Voice[e.Channel]>=0 )
      {						// just adjusting the volume?
      dms->ChanVol[e.Channel]=((int)e.Volume)<<8;

      // make sure the value is in-bounds
      if( dms->ChanVol[e.Channel]<0 ) 
        dms->ChanVol[e.Channel]=0;
      if( dms->ChanVol[e.Channel]>16384 )
        dms->ChanVol[e.Channel]=16384;

      // calculate the left/right volumes
      volr = dms->ChanPan[e.Channel];
      voll = 256-volr;
      vol  = (volglomas * dms->ChanVol[e.Channel]) >> 14;
      volr = (volr * vol) >> 14;
      voll = (voll * vol) >> 14;

      // tell the SPU the good news...
      SsUtSetVVol( dms->Chan2Voice[e.Channel],voll,volr );
      }  // else if( e.Volume<=64 )
    }  // if( e.Channel>=0 && e.Channel<DMS_MAX_CHANNELS )

  // next event, please...
  evptr++;
  result = DMSGetEvent( dms,evptr,&e );
  }  // while( result==DMS_OK && e.Time<=desiredtime )

// now save the event pointer back!
dms->EventPtr = evptr;

// Reset the frame count before exiting.  If we don't do this, it will be
// hellish for sure!
dms->FramesLeft = DMSNumberRowFrames( dms->CurSpeed,dms->CurTempo,
	dms->VideoRefresh );

return(DMS_OK);
}

// ......................................................................
// in:		pointer to DMS structure, volume (0..256)
// out:		DMS_OK | error condition
// desc:	sets the master volume mixing for this DMS
// note:	This DOES NOT have anything to do with the master volume
//		of the SPU!  Set that with the Yaroze library calls.
// ......................................................................
int DMSSetMasterVol( DMS *dms, int vol )
{
// pull the value into range
if( vol<0 )
  vol=0;
if( vol>=DMS_VOL_RESOLUTION )
  vol=DMS_VOL_RESOLUTION-1;

dms->MasterVol = vol;

return(DMS_OK);
}

// ......................................................................
// in:		pointer to DMS structure
// out:		-
// desc:	resets the song pointer to the very beginning!
// note:	probably a good idea to always call this before starting
//		playback from the beginning
// ......................................................................
int DMSSongReset( DMS *dms )
{
dms->CurOrder	= -1;
dms->CurRow	= dms->Rows;
dms->EventPtr	= 0;
dms->EventTime	= 0;
dms->FramesLeft	= -1;
dms->GlobalVol	= 64;

DMSNoteKeyOffAll(dms);
}

// [end]
